# 🌿 DOKA Donations — Food Waste Tracker & Donation Platform

A full-stack MERN web application connecting restaurants with NGOs, charities, and food banks to reduce food waste through food donation management.

---

## 📋 Table of Contents
- [Overview](#overview)
- [Tech Stack](#tech-stack)
- [Features](#features)
- [Project Structure](#project-structure)
- [Setup & Installation](#setup--installation)
- [Environment Variables](#environment-variables)
- [Seed Data & Demo Accounts](#seed-data--demo-accounts)
- [API Documentation](#api-documentation)
- [Donation Workflow](#donation-workflow)
- [Future Enhancements](#future-enhancements)

---

## Overview

DOKA Donations bridges the gap between restaurants with surplus food and organizations serving communities in need. The platform features:
- Restaurant-to-organization food donation management
- Full delivery tracking workflow
- Real-time notifications
- Analytics dashboards
- Admin oversight panel

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React.js, React Router v6, Tailwind CSS, Recharts |
| Backend | Node.js, Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| File Uploads | Cloudinary + Multer |
| Email | Nodemailer |
| HTTP Client | Axios |

---

## Features

### 🔐 Authentication
- Register/Login with JWT
- Role-based access control (Admin, Restaurant, Organization)
- Forgot/Reset password via email
- Protected routes per role

### 🏪 Restaurant Dashboard
- Add/Edit/Delete food listings with images
- Set quantity, category, expiry time, pickup location
- Accept/reject donation requests
- Update delivery status (Pending → Approved → Out for Delivery → Delivered)
- Donation analytics with charts
- Notification center

### 🤝 Organization Dashboard
- Browse & search food donations (by category, city, urgency)
- Submit donation requests
- Track delivery timeline in real-time
- Confirm receipt to complete donation
- Donation history & analytics

### 🛡️ Admin Panel
- Approve/reject restaurant accounts
- User management (activate/suspend/delete)
- Platform-wide analytics
- Reports & issue management
- Send announcements to users

### 📦 Donation Workflow
1. Restaurant posts surplus food listing
2. NGO browses and requests a listing
3. Restaurant approves/rejects request
4. Restaurant marks "Out for Delivery" (adds driver info)
5. Restaurant marks "Delivered"
6. NGO confirms receipt
7. Donation marked "Completed" — analytics updated

---

## Project Structure

```
doka-donations/
├── backend/
│   ├── config/
│   │   ├── database.js          # MongoDB connection
│   │   └── cloudinary.js        # Cloudinary + Multer config
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── foodListingController.js
│   │   ├── donationRequestController.js
│   │   ├── adminController.js
│   │   └── analyticsController.js
│   ├── middleware/
│   │   ├── auth.js              # JWT protect/authorize
│   │   ├── errorHandler.js      # Global error handler
│   │   └── validate.js          # express-validator middleware
│   ├── models/
│   │   ├── User.js
│   │   ├── Restaurant.js
│   │   ├── Organization.js
│   │   ├── FoodListing.js
│   │   ├── DonationRequest.js
│   │   ├── Notification.js
│   │   ├── Report.js
│   │   └── ActivityLog.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── users.js
│   │   ├── restaurants.js
│   │   ├── organizations.js
│   │   ├── foodListings.js
│   │   ├── donationRequests.js
│   │   ├── notifications.js
│   │   ├── analytics.js
│   │   ├── admin.js
│   │   └── upload.js
│   ├── services/
│   │   ├── notificationService.js
│   │   └── emailService.js
│   ├── utils/
│   │   └── seed.js              # Sample data seeder
│   ├── server.js
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   └── common/
    │   │       └── index.js     # StatCard, Modal, FoodCard, DeliveryTimeline, etc.
    │   ├── context/
    │   │   ├── AuthContext.js
    │   │   └── ThemeContext.js
    │   ├── layouts/
    │   │   ├── RestaurantLayout.js
    │   │   ├── OrgLayout.js
    │   │   └── AdminLayout.js
    │   ├── pages/
    │   │   ├── auth/           # Login, Register, ForgotPassword, ResetPassword
    │   │   ├── landing/        # LandingPage
    │   │   ├── restaurant/     # Dashboard, Listings, Donations, Analytics, Profile
    │   │   ├── organization/   # Dashboard, Browse, Donations, Profile
    │   │   └── admin/          # Dashboard, Users, Restaurants, Donations, Reports, Announcements
    │   ├── routes/
    │   │   ├── ProtectedRoute.js
    │   │   └── RoleRoute.js
    │   ├── services/
    │   │   └── api.js           # All Axios API calls
    │   ├── App.js
    │   ├── index.js
    │   └── index.css
    ├── tailwind.config.js
    ├── package.json
    └── .env.example
```

---

## Setup & Installation

### Prerequisites
- Node.js >= 16.x
- MongoDB (local or Atlas)
- Cloudinary account (for image uploads)
- Gmail or SMTP for email (optional, for password reset)

### 1. Clone / Download

```bash
cd doka-donations
```

### 2. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env with your values (see Environment Variables below)
nano .env

# Start development server
npm run dev
```

Backend runs at: `http://localhost:5000`

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
# REACT_APP_API_URL=http://localhost:5000/api

# Start development server
npm start
```

Frontend runs at: `http://localhost:3000`

### 4. Seed Sample Data (Optional but recommended)

```bash
cd backend
npm run seed
```

This creates all demo accounts listed below.

---

## Environment Variables

### Backend (`backend/.env`)

```env
PORT=5000
NODE_ENV=development

# MongoDB
MONGO_URI=mongodb://localhost:27017/doka-donations

# JWT
JWT_SECRET=your_super_secret_jwt_key_change_this
JWT_EXPIRE=7d

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Email (for password reset)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password
EMAIL_FROM=DOKA Donations <noreply@dokadonations.com>

# Frontend URL
CLIENT_URL=http://localhost:3000
```

### Frontend (`frontend/.env`)

```env
REACT_APP_API_URL=http://localhost:5000/api
```

---

## Seed Data & Demo Accounts

After running `npm run seed` in the backend:

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@dokadonations.com | Admin@123 |
| Restaurant 1 (Approved) | restaurant1@dokadonations.com | Rest@123 |
| Restaurant 2 (Approved) | restaurant2@dokadonations.com | Rest@123 |
| Restaurant 3 (Pending) | restaurant3@dokadonations.com | Rest@123 |
| Organization 1 | org1@dokadonations.com | Org@123 |
| Organization 2 | org2@dokadonations.com | Org@123 |

The seed also creates:
- 4 food listings (including 1 urgent listing)
- 1 completed donation request (for analytics data)

---

## API Documentation

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/auth/forgot-password` | Request password reset |
| PUT | `/api/auth/reset-password/:token` | Reset password |
| PUT | `/api/auth/change-password` | Change password (authenticated) |

### Food Listings
| Method | Endpoint | Access |
|--------|----------|--------|
| GET | `/api/food-listings` | All authenticated |
| GET | `/api/food-listings/mine` | Restaurant |
| GET | `/api/food-listings/:id` | All |
| POST | `/api/food-listings` | Restaurant (approved) |
| PUT | `/api/food-listings/:id` | Restaurant / Admin |
| DELETE | `/api/food-listings/:id` | Restaurant / Admin |

### Donation Requests
| Method | Endpoint | Access |
|--------|----------|--------|
| POST | `/api/donation-requests` | Organization |
| GET | `/api/donation-requests/restaurant` | Restaurant |
| GET | `/api/donation-requests/organization` | Organization |
| GET | `/api/donation-requests/:id` | All |
| PUT | `/api/donation-requests/:id/status` | Restaurant |
| PUT | `/api/donation-requests/:id/confirm-receipt` | Organization |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/stats` | Platform statistics |
| GET | `/api/admin/users` | All users |
| PUT | `/api/admin/users/:id/toggle-status` | Activate/suspend user |
| DELETE | `/api/admin/users/:id` | Delete user |
| GET | `/api/admin/restaurants/pending` | Pending applications |
| PUT | `/api/admin/restaurants/:id/approval` | Approve/reject restaurant |
| POST | `/api/admin/announce` | Send announcement |
| GET | `/api/admin/donations` | All donations |
| GET | `/api/admin/reports` | All reports |

---

## Donation Workflow

```
Restaurant adds food listing (status: available)
        ↓
Organization submits request (status: pending)
        ↓
Restaurant reviews → Approve or Reject
        ↓ (if approved)
Listing reserved (status: reserved)
        ↓
Restaurant arranges delivery → "Out for Delivery"
        ↓
Food is delivered → Restaurant marks "Delivered"
        ↓
Organization confirms receipt
        ↓
Donation completed ✅ (analytics updated)
```

---

## Future Enhancements

The project is structured to support these planned features:

1. **Transportation/Logistics Module** — Volunteer drivers, route optimization, real-time GPS tracking
2. **Advanced Search** — Map-based search with radius filtering
3. **Chat/Messaging** — Direct messaging between restaurants and organizations
4. **QR Code Receipts** — Digital donation receipts with QR verification
5. **API Webhooks** — Webhook notifications for status changes
6. **Mobile Apps** — React Native apps for iOS and Android
7. **Recurring Donations** — Schedule recurring food donations
8. **Carbon Footprint Tracking** — CO₂ saved metrics

---

## License

MIT License — Built with 💚 for Nigeria and beyond.
