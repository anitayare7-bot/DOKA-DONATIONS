import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import {
  HomeIcon, UsersIcon, BuildingStorefrontIcon,
  ClipboardDocumentListIcon, FlagIcon, MegaphoneIcon,
  ArrowRightOnRectangleIcon, SunIcon, MoonIcon, Bars3Icon, XMarkIcon
} from '@heroicons/react/24/outline';

const navItems = [
  { path: '/admin/dashboard', icon: HomeIcon, label: 'Dashboard' },
  { path: '/admin/users', icon: UsersIcon, label: 'Users' },
  { path: '/admin/restaurants', icon: BuildingStorefrontIcon, label: 'Restaurants' },
  { path: '/admin/donations', icon: ClipboardDocumentListIcon, label: 'All Donations' },
  { path: '/admin/reports', icon: FlagIcon, label: 'Reports' },
  { path: '/admin/announcements', icon: MegaphoneIcon, label: 'Announcements' },
];

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <div className={`dashboard-layout ${isDark ? 'dark' : ''}`}>
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside className={`dashboard-sidebar ${sidebarOpen ? 'open' : ''} bg-gray-900 dark:bg-gray-950`}>
        <div className="p-6 border-b border-gray-700">
          <NavLink to="/" className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">D</span>
            </div>
            <div>
              <span className="font-display font-bold text-white text-lg leading-tight">DOKA</span>
              <p className="text-xs text-primary-400 font-medium leading-tight">Admin Panel</p>
            </div>
          </NavLink>
        </div>

        <div className="p-4 border-b border-gray-700/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary-900 flex items-center justify-center">
              <span className="text-primary-300 font-semibold text-sm">{user?.name?.charAt(0)?.toUpperCase()}</span>
            </div>
            <div>
              <p className="text-sm font-semibold text-white">{user?.name}</p>
              <p className="text-xs text-gray-400">Administrator</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(({ path, icon: Icon, label }) => (
            <NavLink
              key={path}
              to={path}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-primary-600 text-white'
                    : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                }`
              }
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-700 space-y-1">
          <button onClick={toggleTheme} className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-gray-200 transition-colors">
            {isDark ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
            {isDark ? 'Light Mode' : 'Dark Mode'}
          </button>
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:bg-red-900/20 transition-colors">
            <ArrowRightOnRectangleIcon className="w-5 h-5" />
            Logout
          </button>
        </div>
      </aside>

      <div className="dashboard-main bg-gray-100 dark:bg-gray-950">
        <header className="sticky top-0 z-20 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-4 sm:px-6 h-16 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden p-2 rounded-lg text-gray-500 hover:bg-gray-100">
            {sidebarOpen ? <XMarkIcon className="w-5 h-5" /> : <Bars3Icon className="w-5 h-5" />}
          </button>
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400 ml-auto">Admin Dashboard</span>
        </header>
        <main className="p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
