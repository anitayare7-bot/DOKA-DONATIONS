import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const RoleRoute = ({ role, children }) => {
  const { user } = useAuth();

  if (user?.role !== role) {
    // Redirect to the correct dashboard
    const redirectMap = {
      admin: '/admin/dashboard',
      restaurant: '/restaurant/dashboard',
      organization: '/organization/dashboard',
    };
    return <Navigate to={redirectMap[user?.role] || '/'} replace />;
  }

  return children;
};

export default RoleRoute;
