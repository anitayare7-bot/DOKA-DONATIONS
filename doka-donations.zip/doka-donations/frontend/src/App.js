import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';

// Route guards
import ProtectedRoute from './routes/ProtectedRoute';
import RoleRoute from './routes/RoleRoute';

// Public pages
import LandingPage from './pages/landing/LandingPage';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import ResetPasswordPage from './pages/auth/ResetPasswordPage';

// Restaurant pages
import RestaurantDashboard from './pages/restaurant/Dashboard';
import RestaurantListings from './pages/restaurant/Listings';
import RestaurantDonations from './pages/restaurant/Donations';
import RestaurantDonationDetail from './pages/restaurant/DonationDetail';
import RestaurantAnalytics from './pages/restaurant/Analytics';
import RestaurantProfile from './pages/restaurant/Profile';
import RestaurantNotifications from './pages/restaurant/Notifications';

// Organization pages
import OrgDashboard from './pages/organization/Dashboard';
import OrgBrowse from './pages/organization/Browse';
import OrgDonations from './pages/organization/Donations';
import OrgDonationDetail from './pages/organization/DonationDetail';
import OrgProfile from './pages/organization/Profile';
import OrgNotifications from './pages/organization/Notifications';

// Admin pages
import AdminDashboard from './pages/admin/Dashboard';
import AdminUsers from './pages/admin/Users';
import AdminRestaurants from './pages/admin/Restaurants';
import AdminDonations from './pages/admin/Donations';
import AdminReports from './pages/admin/Reports';
import AdminAnnouncements from './pages/admin/Announcements';

// Layouts
import RestaurantLayout from './layouts/RestaurantLayout';
import OrgLayout from './layouts/OrgLayout';
import AdminLayout from './layouts/AdminLayout';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                borderRadius: '10px',
                fontSize: '14px',
                fontFamily: 'DM Sans, sans-serif',
              },
              success: {
                iconTheme: { primary: '#16a34a', secondary: '#fff' },
              },
            }}
          />
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password/:token" element={<ResetPasswordPage />} />

            {/* Restaurant routes */}
            <Route path="/restaurant" element={
              <ProtectedRoute>
                <RoleRoute role="restaurant">
                  <RestaurantLayout />
                </RoleRoute>
              </ProtectedRoute>
            }>
              <Route index element={<Navigate to="/restaurant/dashboard" replace />} />
              <Route path="dashboard" element={<RestaurantDashboard />} />
              <Route path="listings" element={<RestaurantListings />} />
              <Route path="donations" element={<RestaurantDonations />} />
              <Route path="donations/:id" element={<RestaurantDonationDetail />} />
              <Route path="analytics" element={<RestaurantAnalytics />} />
              <Route path="notifications" element={<RestaurantNotifications />} />
              <Route path="profile" element={<RestaurantProfile />} />
            </Route>

            {/* Organization routes */}
            <Route path="/organization" element={
              <ProtectedRoute>
                <RoleRoute role="organization">
                  <OrgLayout />
                </RoleRoute>
              </ProtectedRoute>
            }>
              <Route index element={<Navigate to="/organization/dashboard" replace />} />
              <Route path="dashboard" element={<OrgDashboard />} />
              <Route path="browse" element={<OrgBrowse />} />
              <Route path="donations" element={<OrgDonations />} />
              <Route path="donations/:id" element={<OrgDonationDetail />} />
              <Route path="notifications" element={<OrgNotifications />} />
              <Route path="profile" element={<OrgProfile />} />
            </Route>

            {/* Admin routes */}
            <Route path="/admin" element={
              <ProtectedRoute>
                <RoleRoute role="admin">
                  <AdminLayout />
                </RoleRoute>
              </ProtectedRoute>
            }>
              <Route index element={<Navigate to="/admin/dashboard" replace />} />
              <Route path="dashboard" element={<AdminDashboard />} />
              <Route path="users" element={<AdminUsers />} />
              <Route path="restaurants" element={<AdminRestaurants />} />
              <Route path="donations" element={<AdminDonations />} />
              <Route path="reports" element={<AdminReports />} />
              <Route path="announcements" element={<AdminAnnouncements />} />
            </Route>

            {/* Catch all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
