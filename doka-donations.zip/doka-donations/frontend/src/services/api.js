import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor - attach token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
  forgotPassword: (email) => api.post('/auth/forgot-password', { email }),
  resetPassword: (token, password) => api.put(`/auth/reset-password/${token}`, { password }),
  changePassword: (data) => api.put('/auth/change-password', data),
};

// Food Listings API
export const foodListingsAPI = {
  getAll: (params) => api.get('/food-listings', { params }),
  getMine: (params) => api.get('/food-listings/mine', { params }),
  getOne: (id) => api.get(`/food-listings/${id}`),
  create: (data) => api.post('/food-listings', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  update: (id, data) => api.put(`/food-listings/${id}`, data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  delete: (id) => api.delete(`/food-listings/${id}`),
  removeImage: (id, publicId) => api.delete(`/food-listings/${id}/images/${encodeURIComponent(publicId)}`),
};

// Donation Requests API
export const donationRequestsAPI = {
  create: (data) => api.post('/donation-requests', data),
  getRestaurantRequests: (params) => api.get('/donation-requests/restaurant', { params }),
  getOrganizationRequests: (params) => api.get('/donation-requests/organization', { params }),
  getOne: (id) => api.get(`/donation-requests/${id}`),
  updateStatus: (id, data) => api.put(`/donation-requests/${id}/status`, data),
  confirmReceipt: (id, data) => api.put(`/donation-requests/${id}/confirm-receipt`, data),
};

// Notifications API
export const notificationsAPI = {
  getAll: (params) => api.get('/notifications', { params }),
  markRead: (id) => api.put(`/notifications/${id}/read`),
  markAllRead: () => api.put('/notifications/mark-all-read'),
  delete: (id) => api.delete(`/notifications/${id}`),
};

// Analytics API
export const analyticsAPI = {
  getRestaurantAnalytics: () => api.get('/analytics/restaurant'),
  getOrganizationAnalytics: () => api.get('/analytics/organization'),
};

// Admin API
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getAllUsers: (params) => api.get('/admin/users', { params }),
  deleteUser: (id) => api.delete(`/admin/users/${id}`),
  toggleUserStatus: (id) => api.put(`/admin/users/${id}/toggle-status`),
  getPendingRestaurants: () => api.get('/admin/restaurants/pending'),
  updateRestaurantApproval: (id, data) => api.put(`/admin/restaurants/${id}/approval`, data),
  sendAnnouncement: (data) => api.post('/admin/announce', data),
  getReports: (params) => api.get('/admin/reports', { params }),
  updateReport: (id, data) => api.put(`/admin/reports/${id}`, data),
  getAllDonations: (params) => api.get('/admin/donations', { params }),
};

// Restaurant API
export const restaurantAPI = {
  getProfile: () => api.get('/restaurants/profile'),
  updateProfile: (data) => api.put('/restaurants/profile', data),
  updateLogo: (data) => api.put('/restaurants/logo', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  getById: (id) => api.get(`/restaurants/${id}`),
  getAll: () => api.get('/restaurants'),
};

// Organization API
export const organizationAPI = {
  getProfile: () => api.get('/organizations/profile'),
  updateProfile: (data) => api.put('/organizations/profile', data),
  updateLogo: (data) => api.put('/organizations/logo', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
};

// User API
export const userAPI = {
  updateProfile: (data) => api.put('/users/profile', data),
  updateAvatar: (data) => api.put('/users/avatar', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
};

export default api;
