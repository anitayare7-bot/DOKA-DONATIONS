import React, { useState, useEffect } from 'react';
import { analyticsAPI } from '../../services/api';
import { StatCard, LoadingPage } from '../../components/common';
import { ChartBarIcon, ScaleIcon, CheckCircleIcon, ClockIcon } from '@heroicons/react/24/outline';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const COLORS = ['#16a34a','#22c55e','#4ade80','#86efac','#a3e635','#65a30d','#15803d','#166534','#3f6212','#1a2e05','#052e16','#ecfdf5'];
const CAT_LABELS = {cooked_meals:'Cooked Meals',raw_produce:'Raw Produce',baked_goods:'Baked Goods',beverages:'Beverages',packaged_food:'Packaged',dairy:'Dairy',meat_poultry:'Meat',seafood:'Seafood',grains_cereals:'Grains',fruits_vegetables:'Fruits & Veg',other:'Other'};

export default function RestaurantAnalytics() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    analyticsAPI.getRestaurantAnalytics()
      .then(res => setData(res.data.data))
      .catch(() => toast.error('Failed to load analytics'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingPage />;

  const monthlyData = data?.monthlyDonations?.map(d => ({
    name: MONTHS[d._id.month - 1],
    donations: d.count,
    weight: parseFloat((d.weightKg || 0).toFixed(1)),
  })) || [];

  const categoryData = data?.categoryBreakdown?.map(c => ({
    name: CAT_LABELS[c._id] || c._id,
    value: c.count,
  })) || [];

  const statusData = data?.statusBreakdown?.map(s => ({
    name: s._id?.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase()),
    value: s.count,
  })) || [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Analytics</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Your food donation impact and statistics</p>
      </div>

      {/* Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Listings" value={data?.overview?.totalListings || 0} icon={ChartBarIcon} color="blue" />
        <StatCard title="Food Saved (kg)" value={`${data?.overview?.totalFoodSavedKg || 0}kg`} icon={ScaleIcon} color="green" />
        <StatCard title="Completed Donations" value={data?.overview?.completedDonations || 0} icon={CheckCircleIcon} color="teal" />
        <StatCard title="Acceptance Rate" value={`${data?.overview?.acceptanceRate || 0}%`} icon={ClockIcon} color="purple" />
      </div>

      {/* Monthly chart */}
      <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
        <h2 className="font-bold text-gray-900 dark:text-white mb-6">Monthly Donations (Last 6 Months)</h2>
        {monthlyData.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ borderRadius:'10px', border:'none', boxShadow:'0 4px 20px rgba(0,0,0,0.1)' }} />
              <Legend />
              <Bar dataKey="donations" name="Donations" fill="#16a34a" radius={[4,4,0,0]} />
              <Bar dataKey="weight" name="Weight (kg)" fill="#a3e635" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-48 flex items-center justify-center text-gray-400 text-sm">No data yet</div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Category breakdown */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white mb-6">Food Categories</h2>
          {categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent*100).toFixed(0)}%`} labelLine={false}>
                  {categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">No data yet</div>
          )}
        </div>

        {/* Request status breakdown */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white mb-6">Request Status Breakdown</h2>
          {statusData.length > 0 ? (
            <div className="space-y-3">
              {statusData.map((s, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-sm text-gray-600 dark:text-gray-400 flex-1 capitalize">{s.name}</span>
                  <div className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-full h-2">
                    <div className="h-2 rounded-full" style={{
                      width: `${(s.value / statusData.reduce((a,b)=>a+b.value,0)*100)}%`,
                      background: COLORS[i % COLORS.length]
                    }} />
                  </div>
                  <span className="text-sm font-semibold text-gray-900 dark:text-white w-8 text-right">{s.value}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">No requests yet</div>
          )}
        </div>
      </div>
    </div>
  );
}
