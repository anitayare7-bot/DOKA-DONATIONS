import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { analyticsAPI, donationRequestsAPI, foodListingsAPI } from '../../services/api';
import { StatCard, StatusBadge, LoadingPage } from '../../components/common';
import {
  ChartBarIcon, ListBulletIcon, InboxIcon, CheckCircleIcon,
  PlusIcon, ArrowRightIcon, ExclamationTriangleIcon
} from '@heroicons/react/24/outline';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function RestaurantDashboard() {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState(null);
  const [recentRequests, setRecentRequests] = useState([]);
  const [urgentListings, setUrgentListings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [analyticsRes, requestsRes, listingsRes] = await Promise.all([
          analyticsAPI.getRestaurantAnalytics(),
          donationRequestsAPI.getRestaurantRequests({ limit: 5 }),
          foodListingsAPI.getMine({ status: 'available', limit: 5 }),
        ]);
        setAnalytics(analyticsRes.data.data);
        setRecentRequests(requestsRes.data.data);
        setUrgentListings(listingsRes.data.data.filter(l => l.isUrgent));
      } catch {
        toast.error('Failed to load dashboard');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <LoadingPage />;

  const chartData = analytics?.monthlyDonations?.map(d => ({
    name: MONTHS[d._id.month - 1],
    donations: d.count,
    kg: d.weightKg || 0,
  })) || [];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">
            Good day, {user?.name?.split(' ')[0]}! 👋
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Here's your donation activity overview</p>
        </div>
        {user?.isApproved && (
          <Link to="/restaurant/listings" className="btn-primary gap-2">
            <PlusIcon className="w-4 h-4" />
            Add Food Listing
          </Link>
        )}
      </div>

      {/* Pending approval banner */}
      {!user?.isApproved && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-xl p-4 flex gap-3">
          <ExclamationTriangleIcon className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-300">Account Pending Approval</p>
            <p className="text-xs text-yellow-700 dark:text-yellow-400 mt-0.5">
              Your restaurant account is being reviewed by our team. You'll be notified once approved and can start posting food listings.
            </p>
          </div>
        </div>
      )}

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Listings" value={analytics?.overview?.totalListings || 0} icon={ListBulletIcon} color="blue" />
        <StatCard title="Active Listings" value={analytics?.overview?.activeListings || 0} icon={ChartBarIcon} color="green" subtitle="Available now" />
        <StatCard title="Pending Requests" value={analytics?.overview?.pendingRequests || 0} icon={InboxIcon} color="orange" />
        <StatCard title="Completed Donations" value={analytics?.overview?.completedDonations || 0} icon={CheckCircleIcon} color="teal" subtitle={`${analytics?.overview?.totalFoodSavedKg || 0}kg saved`} />
      </div>

      {/* Charts + urgent listings */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-bold text-gray-900 dark:text-white">Monthly Donations</h2>
            <span className="text-xs text-gray-500 dark:text-gray-400">Last 6 months</span>
          </div>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ borderRadius: '10px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="donations" name="Donations" fill="#16a34a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">
              No donation data yet. Start by adding food listings!
            </div>
          )}
        </div>

        {/* Urgent Listings */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-gray-900 dark:text-white">⚡ Expiring Soon</h2>
            <Link to="/restaurant/listings" className="text-xs text-primary-600 hover:underline">View all</Link>
          </div>
          {urgentListings.length > 0 ? (
            <div className="space-y-3">
              {urgentListings.map(l => (
                <div key={l._id} className="flex items-center gap-3 p-2.5 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <span className="text-xl">🍽️</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 truncate">{l.title}</p>
                    <p className="text-xs text-red-500">{l.quantity?.amount} {l.quantity?.unit}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400 dark:text-gray-500 text-center py-8">No urgent listings</p>
          )}
        </div>
      </div>

      {/* Recent Donation Requests */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white">Recent Donation Requests</h2>
          <Link to="/restaurant/donations" className="text-sm text-primary-600 hover:underline flex items-center gap-1">
            View all <ArrowRightIcon className="w-3.5 h-3.5" />
          </Link>
        </div>
        <div className="divide-y divide-gray-100 dark:divide-gray-800">
          {recentRequests.length === 0 ? (
            <div className="p-8 text-center text-gray-400 text-sm">No donation requests yet</div>
          ) : (
            recentRequests.map(req => (
              <div key={req._id} className="p-4 flex items-center gap-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                    {req.foodListing?.title || 'Food Listing'}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    by {req.organization?.organizationName || 'Organization'}
                  </p>
                </div>
                <StatusBadge status={req.status} />
                <Link to={`/restaurant/donations/${req._id}`} className="text-xs text-primary-600 hover:underline">
                  View →
                </Link>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
