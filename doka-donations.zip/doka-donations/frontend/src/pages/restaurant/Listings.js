import React, { useState, useEffect, useRef } from 'react';
import { foodListingsAPI } from '../../services/api';
import { StatusBadge, CategoryBadge, Modal, EmptyState, Pagination, LoadingPage } from '../../components/common';
import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon, PhotoIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const CATEGORIES = ['cooked_meals','raw_produce','baked_goods','beverages','packaged_food','dairy','meat_poultry','seafood','grains_cereals','fruits_vegetables','other'];
const UNITS = ['kg','lbs','liters','portions','boxes','bags','trays','pieces'];
const EMPTY_FORM = {
  title: '', description: '', category: 'cooked_meals',
  quantityAmount: '', quantityUnit: 'kg', estimatedWeight: '',
  expiryTime: '', city: '', street: '', state: '',
  isVegetarian: false, isVegan: false, isHalal: false,
  tags: '', images: [], newImages: [],
};

export default function RestaurantListings() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editListing, setEditListing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [statusFilter, setStatusFilter] = useState('');
  const [deleteId, setDeleteId] = useState(null);
  const fileRef = useRef();

  const fetchListings = async (p = 1) => {
    try {
      const params = { page: p, limit: 10 };
      if (statusFilter) params.status = statusFilter;
      const { data } = await foodListingsAPI.getMine(params);
      setListings(data.data);
      setPagination(data.pagination);
    } catch { toast.error('Failed to load listings'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchListings(page); }, [page, statusFilter]);

  const openModal = (listing = null) => {
    if (listing) {
      setEditListing(listing);
      setForm({
        title: listing.title || '',
        description: listing.description || '',
        category: listing.category || 'cooked_meals',
        quantityAmount: listing.quantity?.amount || '',
        quantityUnit: listing.quantity?.unit || 'kg',
        estimatedWeight: listing.estimatedWeight || '',
        expiryTime: listing.expiryTime ? new Date(listing.expiryTime).toISOString().slice(0,16) : '',
        city: listing.pickupLocation?.city || '',
        street: listing.pickupLocation?.street || '',
        state: listing.pickupLocation?.state || '',
        isVegetarian: listing.dietaryInfo?.isVegetarian || false,
        isVegan: listing.dietaryInfo?.isVegan || false,
        isHalal: listing.dietaryInfo?.isHalal || false,
        tags: (listing.tags || []).join(', '),
        images: listing.images || [],
        newImages: [],
      });
    } else {
      setEditListing(null);
      setForm(EMPTY_FORM);
    }
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData();
      fd.append('title', form.title);
      fd.append('description', form.description);
      fd.append('category', form.category);
      fd.append('quantity[amount]', form.quantityAmount);
      fd.append('quantity[unit]', form.quantityUnit);
      fd.append('estimatedWeight', form.estimatedWeight || form.quantityAmount);
      fd.append('expiryTime', form.expiryTime);
      fd.append('pickupLocation[city]', form.city);
      fd.append('pickupLocation[street]', form.street);
      fd.append('pickupLocation[state]', form.state);
      fd.append('dietaryInfo[isVegetarian]', form.isVegetarian);
      fd.append('dietaryInfo[isVegan]', form.isVegan);
      fd.append('dietaryInfo[isHalal]', form.isHalal);
      if (form.tags) fd.append('tags', JSON.stringify(form.tags.split(',').map(t => t.trim()).filter(Boolean)));
      form.newImages.forEach(f => fd.append('images', f));

      if (editListing) {
        await foodListingsAPI.update(editListing._id, fd);
        toast.success('Listing updated!');
      } else {
        await foodListingsAPI.create(fd);
        toast.success('Listing created!');
      }
      setShowModal(false);
      fetchListings(page);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await foodListingsAPI.delete(deleteId);
      toast.success('Listing deleted');
      setDeleteId(null);
      fetchListings(page);
    } catch { toast.error('Delete failed'); }
  };

  if (loading) return <LoadingPage />;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Food Listings</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Manage your surplus food donations</p>
        </div>
        <button onClick={() => openModal()} className="btn-primary gap-2">
          <PlusIcon className="w-4 h-4" /> Add Listing
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        {['','available','pending','reserved','completed','expired'].map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-colors ${
              statusFilter === s ? 'bg-primary-600 text-white border-primary-600' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-300 dark:border-gray-600 hover:border-primary-400'
            }`}>
            {s ? s.charAt(0).toUpperCase() + s.slice(1) : 'All'}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {listings.length === 0 ? (
          <EmptyState icon="🍽️" title="No Food Listings" description="Start adding surplus food to connect with organizations in need."
            action={<button onClick={() => openModal()} className="btn-primary">Add First Listing</button>} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                <tr>
                  {['Food', 'Category', 'Quantity', 'Expiry', 'Status', 'Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {listings.map(l => (
                  <tr key={l._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-gray-100 dark:bg-gray-800 overflow-hidden flex-shrink-0">
                          {l.images?.[0]?.url ? (
                            <img src={l.images[0].url} alt={l.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-lg">🍽️</div>
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white truncate max-w-[160px]">{l.title}</p>
                          {l.isUrgent && <span className="text-xs text-red-500 font-semibold">⚡ Urgent</span>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3"><CategoryBadge category={l.category} /></td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{l.quantity?.amount} {l.quantity?.unit}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400 text-xs">
                      {new Date(l.expiryTime).toLocaleString()}
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={l.status} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button onClick={() => openModal(l)} className="p-1.5 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 text-primary-600 transition-colors">
                          <PencilIcon className="w-4 h-4" />
                        </button>
                        <button onClick={() => setDeleteId(l._id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 transition-colors">
                          <TrashIcon className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />

      {/* Delete Confirm */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setDeleteId(null)} />
          <div className="relative bg-white dark:bg-gray-900 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-gray-900 dark:text-white text-lg mb-2">Delete Listing?</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="flex-1 btn-secondary">Cancel</button>
              <button onClick={handleDelete} className="flex-1 btn-danger">Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal isOpen={showModal} onClose={() => setShowModal(false)} title={editListing ? 'Edit Food Listing' : 'Add Food Listing'} size="xl">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="form-label">Title *</label>
              <input className="form-input" placeholder="e.g. Jollof Rice & Stew" required
                value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
            </div>
            <div className="sm:col-span-2">
              <label className="form-label">Description</label>
              <textarea className="form-input resize-none" rows={2} placeholder="Describe the food..."
                value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
            </div>
            <div>
              <label className="form-label">Category *</label>
              <select className="form-input" value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c.replace(/_/g,' ').replace(/\b\w/g, l => l.toUpperCase())}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Expiry Date & Time *</label>
              <input type="datetime-local" className="form-input" required
                value={form.expiryTime} onChange={e => setForm({...form, expiryTime: e.target.value})} />
            </div>
            <div>
              <label className="form-label">Quantity *</label>
              <div className="flex gap-2">
                <input type="number" className="form-input" placeholder="Amount" min="0.1" step="0.1" required
                  value={form.quantityAmount} onChange={e => setForm({...form, quantityAmount: e.target.value})} />
                <select className="form-input w-28" value={form.quantityUnit} onChange={e => setForm({...form, quantityUnit: e.target.value})}>
                  {UNITS.map(u => <option key={u}>{u}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="form-label">Est. Weight (kg)</label>
              <input type="number" className="form-input" placeholder="for analytics" min="0"
                value={form.estimatedWeight} onChange={e => setForm({...form, estimatedWeight: e.target.value})} />
            </div>
            <div>
              <label className="form-label">Pickup City *</label>
              <input className="form-input" placeholder="e.g. Abuja" required
                value={form.city} onChange={e => setForm({...form, city: e.target.value})} />
            </div>
            <div>
              <label className="form-label">Pickup Street</label>
              <input className="form-input" placeholder="Street address"
                value={form.street} onChange={e => setForm({...form, street: e.target.value})} />
            </div>
            <div className="sm:col-span-2">
              <label className="form-label">Tags (comma separated)</label>
              <input className="form-input" placeholder="rice, halal, party food"
                value={form.tags} onChange={e => setForm({...form, tags: e.target.value})} />
            </div>
            <div className="sm:col-span-2">
              <label className="form-label">Dietary Info</label>
              <div className="flex flex-wrap gap-4">
                {[['isVegetarian','Vegetarian'],['isVegan','Vegan'],['isHalal','Halal']].map(([key, label]) => (
                  <label key={key} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded text-primary-600"
                      checked={form[key]} onChange={e => setForm({...form, [key]: e.target.checked})} />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{label}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="sm:col-span-2">
              <label className="form-label">Food Images (up to 5)</label>
              <div
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 text-center cursor-pointer hover:border-primary-400 transition-colors">
                <PhotoIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-500 dark:text-gray-400">Click to upload images</p>
                <input type="file" ref={fileRef} multiple accept="image/*" className="hidden"
                  onChange={e => setForm({...form, newImages: Array.from(e.target.files)})} />
              </div>
              {form.newImages.length > 0 && (
                <p className="text-xs text-primary-600 mt-1.5">{form.newImages.length} file(s) selected</p>
              )}
            </div>
          </div>

          <div className="flex gap-3 pt-2 border-t border-gray-100 dark:border-gray-800">
            <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Saving...' : editListing ? 'Update Listing' : 'Create Listing'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
