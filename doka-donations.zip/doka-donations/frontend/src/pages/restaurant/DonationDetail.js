import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { donationRequestsAPI } from '../../services/api';
import { StatusBadge, DeliveryTimeline, Modal, LoadingPage } from '../../components/common';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function RestaurantDonationDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showActionModal, setShowActionModal] = useState(false);
  const [action, setAction] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    note: '', deliveryPersonName: '', deliveryPersonPhone: '', estimatedDeliveryTime: ''
  });

  const load = async () => {
    try {
      const { data } = await donationRequestsAPI.getOne(id);
      setRequest(data.data);
    } catch { toast.error('Failed to load request'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [id]);

  const handleAction = (actionType) => {
    setAction(actionType);
    setForm({ note: '', deliveryPersonName: '', deliveryPersonPhone: '', estimatedDeliveryTime: '' });
    setShowActionModal(true);
  };

  const handleSubmitAction = async () => {
    setSaving(true);
    try {
      const payload = { status: action, ...form };
      await donationRequestsAPI.updateStatus(id, payload);
      toast.success(`Status updated to ${action.replace(/_/g,' ')}`);
      setShowActionModal(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Action failed');
    } finally { setSaving(false); }
  };

  if (loading) return <LoadingPage />;
  if (!request) return <div className="text-center py-20 text-gray-400">Request not found</div>;

  const { foodListing, organization, status, requestNote, statusHistory, deliveryPersonName, deliveryPersonPhone } = request;

  const getAvailableActions = () => {
    if (status === 'pending') return [
      { label: '✅ Approve', action: 'approved', color: 'btn-primary' },
      { label: '❌ Reject', action: 'rejected', color: 'btn-danger' },
    ];
    if (status === 'approved') return [{ label: '🚚 Mark Out for Delivery', action: 'out_for_delivery', color: 'btn-primary' }];
    if (status === 'out_for_delivery') return [{ label: '📦 Mark as Delivered', action: 'delivered', color: 'btn-primary' }];
    return [];
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/restaurant/donations')} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 transition-colors">
          <ArrowLeftIcon className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Donation Request</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">#{id.slice(-8).toUpperCase()}</p>
        </div>
        <div className="ml-auto"><StatusBadge status={status} /></div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Food Listing Info */}
          <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
            <h2 className="font-bold text-gray-900 dark:text-white mb-4">Food Details</h2>
            <div className="flex gap-4">
              <div className="w-20 h-20 rounded-xl bg-gray-100 dark:bg-gray-800 overflow-hidden flex-shrink-0">
                {foodListing?.images?.[0]?.url ? (
                  <img src={foodListing.images[0].url} alt="" className="w-full h-full object-cover" />
                ) : <div className="w-full h-full flex items-center justify-center text-3xl">🍽️</div>}
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{foodListing?.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{foodListing?.description}</p>
                <div className="flex gap-4 mt-2 text-sm text-gray-600 dark:text-gray-400">
                  <span>📦 {foodListing?.quantity?.amount} {foodListing?.quantity?.unit}</span>
                  <span>⏰ Expires {new Date(foodListing?.expiryTime).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Organization Info */}
          <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
            <h2 className="font-bold text-gray-900 dark:text-white mb-4">Requesting Organization</h2>
            <div className="space-y-2 text-sm">
              <p><span className="text-gray-500 dark:text-gray-400">Name:</span> <span className="font-semibold text-gray-800 dark:text-gray-200 ml-2">{organization?.organizationName}</span></p>
              <p><span className="text-gray-500 dark:text-gray-400">Type:</span> <span className="ml-2 text-gray-700 dark:text-gray-300 capitalize">{organization?.type?.replace('_',' ')}</span></p>
              <p><span className="text-gray-500 dark:text-gray-400">City:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{organization?.address?.city}</span></p>
              {request.requestNote && (
                <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-1">Request Note:</p>
                  <p className="text-sm text-blue-600 dark:text-blue-300">{requestNote}</p>
                </div>
              )}
            </div>
          </div>

          {/* Delivery info if set */}
          {deliveryPersonName && (
            <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
              <h2 className="font-bold text-gray-900 dark:text-white mb-4">Delivery Information</h2>
              <div className="space-y-2 text-sm">
                <p><span className="text-gray-500 dark:text-gray-400">Delivery Person:</span> <span className="ml-2 font-medium text-gray-800 dark:text-gray-200">{deliveryPersonName}</span></p>
                <p><span className="text-gray-500 dark:text-gray-400">Phone:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{deliveryPersonPhone}</span></p>
                {request.estimatedDeliveryTime && (
                  <p><span className="text-gray-500 dark:text-gray-400">ETA:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{new Date(request.estimatedDeliveryTime).toLocaleString()}</span></p>
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          {getAvailableActions().length > 0 && (
            <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
              <h2 className="font-bold text-gray-900 dark:text-white mb-4">Actions</h2>
              <div className="flex flex-wrap gap-3">
                {getAvailableActions().map(a => (
                  <button key={a.action} onClick={() => handleAction(a.action)} className={`${a.color} px-5 py-2.5`}>
                    {a.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Timeline */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800 h-fit">
          <h2 className="font-bold text-gray-900 dark:text-white mb-6">Delivery Timeline</h2>
          <DeliveryTimeline statusHistory={statusHistory} />
        </div>
      </div>

      {/* Action Modal */}
      <Modal isOpen={showActionModal} onClose={() => setShowActionModal(false)}
        title={`${action?.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())} - Update Status`} size="md">
        <div className="space-y-4">
          {action === 'out_for_delivery' && (
            <>
              <div>
                <label className="form-label">Delivery Person Name *</label>
                <input className="form-input" placeholder="Driver/delivery person name"
                  value={form.deliveryPersonName} onChange={e => setForm({...form, deliveryPersonName: e.target.value})} required />
              </div>
              <div>
                <label className="form-label">Delivery Person Phone</label>
                <input className="form-input" placeholder="+234..."
                  value={form.deliveryPersonPhone} onChange={e => setForm({...form, deliveryPersonPhone: e.target.value})} />
              </div>
              <div>
                <label className="form-label">Estimated Delivery Time</label>
                <input type="datetime-local" className="form-input"
                  value={form.estimatedDeliveryTime} onChange={e => setForm({...form, estimatedDeliveryTime: e.target.value})} />
              </div>
            </>
          )}
          <div>
            <label className="form-label">
              {action === 'rejected' ? 'Rejection Reason *' : 'Note (optional)'}
            </label>
            <textarea className="form-input resize-none" rows={3}
              placeholder={action === 'rejected' ? 'Explain why you are rejecting...' : 'Add a note...'}
              value={form.note} onChange={e => setForm({...form, note: e.target.value})} />
          </div>
          <div className="flex gap-3">
            <button onClick={() => setShowActionModal(false)} className="flex-1 btn-secondary">Cancel</button>
            <button onClick={handleSubmitAction} disabled={saving} className={`flex-1 ${action === 'rejected' ? 'btn-danger' : 'btn-primary'}`}>
              {saving ? 'Updating...' : 'Confirm'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
