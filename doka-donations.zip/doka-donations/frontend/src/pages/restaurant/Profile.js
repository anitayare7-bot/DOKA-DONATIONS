// Restaurant Profile Page
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { restaurantAPI, userAPI, authAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function RestaurantProfile() {
  const { user, updateUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState('profile');
  const [form, setForm] = useState({ restaurantName:'', description:'', contactPhone:'', street:'', city:'', state:'' });
  const [pwForm, setPwForm] = useState({ currentPassword:'', newPassword:'', confirm:'' });

  useEffect(() => {
    restaurantAPI.getProfile()
      .then(res => {
        setProfile(res.data.data);
        const d = res.data.data;
        setForm({
          restaurantName: d.restaurantName||'', description: d.description||'',
          contactPhone: d.contactPhone||'', street: d.address?.street||'',
          city: d.address?.city||'', state: d.address?.state||'',
        });
      })
      .catch(() => toast.error('Failed to load profile'))
      .finally(() => setLoading(false));
  }, []);

  const saveProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await restaurantAPI.updateProfile({
        ...form, address: { street:form.street, city:form.city, state:form.state, country:'Nigeria' }
      });
      setProfile(data.data);
      toast.success('Profile updated!');
    } catch { toast.error('Save failed'); }
    finally { setSaving(false); }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirm) return toast.error('Passwords do not match');
    setSaving(true);
    try {
      await authAPI.changePassword({ currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      toast.success('Password changed!');
      setPwForm({ currentPassword:'', newPassword:'', confirm:'' });
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="text-center py-20 text-gray-400">Loading...</div>;

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Profile Settings</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Manage your restaurant information</p>
      </div>

      {/* Account status */}
      <div className={`rounded-xl p-4 border ${user?.isApproved ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' : 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800'}`}>
        <p className={`text-sm font-semibold ${user?.isApproved ? 'text-green-700 dark:text-green-400' : 'text-yellow-700 dark:text-yellow-400'}`}>
          {user?.isApproved ? '✅ Account Approved & Active' : '⏳ Account Pending Approval'}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 dark:bg-gray-800 rounded-xl p-1">
        {[['profile','Restaurant Info'],['password','Change Password']].map(([id,label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${tab===id ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
            {label}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <form onSubmit={saveProfile} className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800 space-y-4">
          <div>
            <label className="form-label">Restaurant Name</label>
            <input className="form-input" value={form.restaurantName} onChange={e=>setForm({...form,restaurantName:e.target.value})} />
          </div>
          <div>
            <label className="form-label">Description</label>
            <textarea className="form-input resize-none" rows={3} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} />
          </div>
          <div>
            <label className="form-label">Contact Phone</label>
            <input className="form-input" value={form.contactPhone} onChange={e=>setForm({...form,contactPhone:e.target.value})} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">City</label>
              <input className="form-input" value={form.city} onChange={e=>setForm({...form,city:e.target.value})} />
            </div>
            <div>
              <label className="form-label">State</label>
              <input className="form-input" value={form.state} onChange={e=>setForm({...form,state:e.target.value})} />
            </div>
          </div>
          <div>
            <label className="form-label">Street Address</label>
            <input className="form-input" value={form.street} onChange={e=>setForm({...form,street:e.target.value})} />
          </div>
          <button type="submit" disabled={saving} className="w-full btn-primary py-2.5">
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      )}

      {tab === 'password' && (
        <form onSubmit={changePassword} className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800 space-y-4">
          {[['currentPassword','Current Password'],['newPassword','New Password'],['confirm','Confirm New Password']].map(([key,label]) => (
            <div key={key}>
              <label className="form-label">{label}</label>
              <input type="password" className="form-input" value={pwForm[key]} onChange={e=>setPwForm({...pwForm,[key]:e.target.value})} required />
            </div>
          ))}
          <button type="submit" disabled={saving} className="w-full btn-primary py-2.5">
            {saving ? 'Changing...' : 'Change Password'}
          </button>
        </form>
      )}
    </div>
  );
}
