import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { donationRequestsAPI } from '../../services/api';
import { StatusBadge, Pagination, EmptyState, LoadingPage } from '../../components/common';
import toast from 'react-hot-toast';

const STATUSES = ['','pending','approved','out_for_delivery','delivered','completed','rejected'];

export default function RestaurantDonations() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [statusFilter, setStatusFilter] = useState('');

  const fetchRequests = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 10 };
      if (statusFilter) params.status = statusFilter;
      const { data } = await donationRequestsAPI.getRestaurantRequests(params);
      setRequests(data.data);
      setPagination(data.pagination);
    } catch { toast.error('Failed to load requests'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchRequests(page); }, [page, statusFilter]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Donation Requests</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Manage incoming food donation requests</p>
      </div>

      {/* Status filters */}
      <div className="flex gap-2 flex-wrap">
        {STATUSES.map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-colors ${
              statusFilter === s ? 'bg-primary-600 text-white border-primary-600' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-300 dark:border-gray-600 hover:border-primary-400'
            }`}>
            {s ? s.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase()) : 'All Statuses'}
          </button>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-400">Loading...</div>
        ) : requests.length === 0 ? (
          <EmptyState icon="📬" title="No Requests Yet" description="When organizations request your food listings, they'll appear here." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                <tr>
                  {['Food Item','Organization','Requested','Status','Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {requests.map(req => (
                  <tr key={req._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-gray-100 dark:bg-gray-800 overflow-hidden flex-shrink-0">
                          {req.foodListing?.images?.[0]?.url ? (
                            <img src={req.foodListing.images[0].url} alt="" className="w-full h-full object-cover" />
                          ) : <div className="w-full h-full flex items-center justify-center">🍽️</div>}
                        </div>
                        <p className="font-medium text-gray-900 dark:text-white truncate max-w-[140px]">
                          {req.foodListing?.title || 'N/A'}
                        </p>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium text-gray-800 dark:text-gray-200">{req.organization?.organizationName}</p>
                      <p className="text-xs text-gray-500">{req.organization?.type?.replace('_',' ')}</p>
                    </td>
                    <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs">
                      {new Date(req.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={req.status} /></td>
                    <td className="px-4 py-3">
                      <Link to={`/restaurant/donations/${req._id}`} className="text-xs btn-primary py-1.5 px-3">
                        Manage →
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />
    </div>
  );
}
