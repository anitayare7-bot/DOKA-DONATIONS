import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { SunIcon, MoonIcon, Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const stats = [
  { value: '2,400+', label: 'Meals Donated' },
  { value: '180+', label: 'Partner Restaurants' },
  { value: '95+', label: 'NGOs Served' },
  { value: '12.5t', label: 'Food Waste Prevented' },
];

const steps = [
  { icon: '🍽️', title: 'Restaurant Posts Surplus', desc: 'Restaurants list leftover food with details like quantity, category, and expiry time.' },
  { icon: '🔍', title: 'NGO Browses & Requests', desc: 'Organizations browse available listings and submit donation requests.' },
  { icon: '✅', title: 'Restaurant Approves', desc: 'The restaurant reviews and approves the request, then arranges delivery.' },
  { icon: '🚚', title: 'Food is Delivered', desc: 'The restaurant delivers food directly to the organization\'s location.' },
  { icon: '🤝', title: 'Impact Confirmed', desc: 'The organization confirms receipt. Analytics update automatically.' },
];

const testimonials = [
  { name: 'Chef Emeka Obi', role: 'Restaurant Owner, Abuja', text: 'DOKA Donations transformed how we handle our surplus food. Instead of waste, we now create impact every day.', avatar: '👨‍🍳' },
  { name: 'Ngozi Adeyemi', role: 'Director, Hope Foundation', text: 'We\'ve received over 50 donations through DOKA. The platform is simple to use and the food quality is always great.', avatar: '👩‍💼' },
  { name: 'Amaka Osei', role: 'Catering Manager, Lagos', text: 'Reducing our food waste while helping communities — DOKA makes it seamless for our entire catering team.', avatar: '👩‍🍳' },
];

export default function LandingPage() {
  const { isAuthenticated, user } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getDashboardLink = () => {
    if (!user) return '/login';
    const map = { admin: '/admin/dashboard', restaurant: '/restaurant/dashboard', organization: '/organization/dashboard' };
    return map[user.role] || '/login';
  };

  return (
    <div className={`min-h-screen ${isDark ? 'dark' : ''}`}>
      <div className="bg-white dark:bg-gray-950 text-gray-900 dark:text-white">

        {/* Navbar */}
        <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm shadow-md' : 'bg-transparent'}`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center shadow-glow">
                  <span className="text-white font-bold text-lg">D</span>
                </div>
                <div>
                  <span className="font-display font-bold text-gray-900 dark:text-white text-xl leading-tight">DOKA</span>
                  <span className="text-primary-600 font-semibold text-xl ml-1">Donations</span>
                </div>
              </div>

              {/* Desktop nav */}
              <div className="hidden md:flex items-center gap-8">
                <a href="#about" className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors">About</a>
                <a href="#how-it-works" className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors">How It Works</a>
                <a href="#impact" className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors">Impact</a>
              </div>

              <div className="hidden md:flex items-center gap-3">
                <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400">
                  {isDark ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
                </button>
                {isAuthenticated ? (
                  <Link to={getDashboardLink()} className="btn-primary">Dashboard →</Link>
                ) : (
                  <>
                    <Link to="/login" className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-primary-600 px-3 py-2">Login</Link>
                    <Link to="/register" className="btn-primary">Get Started</Link>
                  </>
                )}
              </div>

              <button className="md:hidden p-2" onClick={() => setMenuOpen(!menuOpen)}>
                {menuOpen ? <XMarkIcon className="w-6 h-6" /> : <Bars3Icon className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          {menuOpen && (
            <div className="md:hidden bg-white dark:bg-gray-900 border-t dark:border-gray-700 px-4 py-4 space-y-3">
              <a href="#about" className="block text-sm font-medium text-gray-700 dark:text-gray-300 py-2">About</a>
              <a href="#how-it-works" className="block text-sm font-medium text-gray-700 dark:text-gray-300 py-2">How It Works</a>
              <a href="#impact" className="block text-sm font-medium text-gray-700 dark:text-gray-300 py-2">Impact</a>
              <div className="flex gap-2 pt-2">
                {isAuthenticated ? (
                  <Link to={getDashboardLink()} className="flex-1 btn-primary text-center">Dashboard</Link>
                ) : (
                  <>
                    <Link to="/login" className="flex-1 btn-secondary text-center">Login</Link>
                    <Link to="/register" className="flex-1 btn-primary text-center">Register</Link>
                  </>
                )}
              </div>
            </div>
          )}
        </nav>

        {/* Hero */}
        <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-emerald-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950" />
          <div className="absolute top-20 right-10 w-96 h-96 bg-primary-200/30 dark:bg-primary-900/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-10 w-72 h-72 bg-emerald-200/40 dark:bg-emerald-900/10 rounded-full blur-3xl" />

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-primary-50 dark:bg-primary-900/30 border border-primary-200 dark:border-primary-800 text-primary-700 dark:text-primary-300 px-4 py-1.5 rounded-full text-sm font-semibold mb-6 animate-fade-in">
                🌿 Reducing Food Waste Across Nigeria
              </div>
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6 animate-slide-up">
                Turn Surplus Food
                <span className="block text-primary-600 dark:text-primary-400">Into Impact</span>
              </h1>
              <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 mb-8 leading-relaxed max-w-2xl animate-fade-in">
                DOKA Donations connects restaurants with NGOs, food banks, and charities to ensure surplus food feeds communities instead of filling landfills.
              </p>
              <div className="flex flex-wrap gap-4 animate-slide-up">
                <Link to="/register" className="btn-primary text-base px-6 py-3 shadow-glow">
                  Start Donating Today →
                </Link>
                <a href="#how-it-works" className="btn-secondary text-base px-6 py-3">
                  See How It Works
                </a>
              </div>
            </div>

            {/* Floating cards */}
            <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 space-y-4">
              {[
                { emoji: '🍲', text: 'Jollof Rice — 25kg', sub: 'Available Now', color: 'bg-green-50 border-green-200' },
                { emoji: '🍞', text: 'Fresh Bread Rolls', sub: 'Expires in 3hrs ⚡', color: 'bg-orange-50 border-orange-200' },
                { emoji: '🥬', text: 'Fresh Vegetables', sub: 'Reserved by NGO', color: 'bg-blue-50 border-blue-200' },
              ].map((card, i) => (
                <div key={i} className={`${card.color} dark:bg-gray-800 dark:border-gray-700 border rounded-xl p-4 shadow-card w-56 animate-fade-in`} style={{ animationDelay: `${i * 0.2}s` }}>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{card.emoji}</span>
                    <div>
                      <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">{card.text}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{card.sub}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section id="impact" className="bg-primary-600 dark:bg-primary-800 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, i) => (
                <div key={i} className="text-center">
                  <p className="text-4xl font-display font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-primary-100 text-sm font-medium">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About */}
        <section id="about" className="py-20 bg-white dark:bg-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">About DOKA</span>
                <h2 className="font-display text-4xl font-bold text-gray-900 dark:text-white mt-2 mb-6">
                  Fighting Hunger & Waste Simultaneously
                </h2>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">
                  Nigeria wastes an estimated 40% of its food every year — while millions go hungry. DOKA Donations bridges this gap by creating a direct, efficient channel between food businesses and the organizations serving those most in need.
                </p>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                  Our platform ensures food is redistributed with dignity, transparency, and speed — before it spoils. Restaurants manage their surplus responsibly while NGOs receive reliable, quality food donations delivered to their doorstep.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: '♻️', text: 'Reduce food waste' },
                    { icon: '🤝', text: 'Build community ties' },
                    { icon: '📊', text: 'Track real impact' },
                    { icon: '🚀', text: 'Fast, simple workflow' },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                      <span>{item.icon}</span> {item.text}
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary-100 to-emerald-100 dark:from-primary-900/40 dark:to-emerald-900/40 flex items-center justify-center">
                  <div className="text-9xl">🌿</div>
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white dark:bg-gray-800 rounded-2xl shadow-card-hover p-4 border border-gray-100 dark:border-gray-700">
                  <p className="text-2xl font-display font-bold text-primary-600">12.5 tons</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Food waste prevented</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="how-it-works" className="py-20 bg-gray-50 dark:bg-gray-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">Simple Process</span>
              <h2 className="font-display text-4xl font-bold text-gray-900 dark:text-white mt-2">How It Works</h2>
              <p className="text-gray-500 dark:text-gray-400 mt-3 max-w-xl mx-auto">
                From surplus food to community impact in five simple steps
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
              {steps.map((step, i) => (
                <div key={i} className="relative text-center">
                  {i < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-[calc(50%+2rem)] w-full h-px border-t-2 border-dashed border-primary-200 dark:border-primary-800" />
                  )}
                  <div className="relative z-10 w-16 h-16 bg-primary-50 dark:bg-primary-900/30 border-2 border-primary-200 dark:border-primary-700 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">
                    {step.icon}
                  </div>
                  <div className="absolute -top-1 -right-1 z-20 w-6 h-6 bg-primary-600 rounded-full flex items-center justify-center text-white text-xs font-bold hidden lg:flex">
                    {i + 1}
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-white text-sm mb-2">{step.title}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-white dark:bg-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">Testimonials</span>
              <h2 className="font-display text-4xl font-bold text-gray-900 dark:text-white mt-2">What They Say</h2>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((t, i) => (
                <div key={i} className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 card-hover">
                  <div className="text-3xl mb-4">"</div>
                  <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed mb-6 italic">{t.text}</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-xl">
                      {t.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-gray-900 dark:text-white">{t.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{t.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gradient-to-r from-primary-600 to-emerald-600 dark:from-primary-800 dark:to-emerald-800">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-4">Ready to Make a Difference?</h2>
            <p className="text-primary-100 text-lg mb-8 max-w-2xl mx-auto">
              Join hundreds of restaurants and organizations across Nigeria making a real impact through food donation.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/register" className="bg-white text-primary-700 font-semibold px-8 py-3 rounded-xl hover:bg-primary-50 transition-colors shadow-lg">
                Join as Restaurant
              </Link>
              <Link to="/register" className="bg-primary-700 text-white font-semibold px-8 py-3 rounded-xl hover:bg-primary-800 border border-primary-500 transition-colors">
                Join as NGO / Charity
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900 dark:bg-gray-950 text-gray-400 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div className="md:col-span-2">
                <div className="flex items-center gap-2.5 mb-4">
                  <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">D</span>
                  </div>
                  <span className="font-display font-bold text-white text-xl">DOKA Donations</span>
                </div>
                <p className="text-sm leading-relaxed max-w-xs">
                  Connecting restaurants with communities to reduce food waste and fight hunger across Nigeria.
                </p>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Platform</h4>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/register" className="hover:text-primary-400 transition-colors">For Restaurants</Link></li>
                  <li><Link to="/register" className="hover:text-primary-400 transition-colors">For NGOs</Link></li>
                  <li><Link to="/login" className="hover:text-primary-400 transition-colors">Login</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Contact</h4>
                <ul className="space-y-2 text-sm">
                  <li>📧 hello@dokadonations.com</li>
                  <li>📞 +234 800 000 0000</li>
                  <li>📍 Abuja, Nigeria</li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 pt-6 text-center text-xs">
              <p>© {new Date().getFullYear()} DOKA Donations. All rights reserved. Built with 💚 for Nigeria.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
