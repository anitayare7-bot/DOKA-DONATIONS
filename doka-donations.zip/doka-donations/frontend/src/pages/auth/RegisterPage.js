import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';

const roles = [
  { id: 'restaurant', label: 'Restaurant / Catering', icon: '🍽️', desc: 'I have surplus food to donate' },
  { id: 'organization', label: 'NGO / Charity / Food Bank', icon: '🤝', desc: 'I represent an organization receiving donations' },
];

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedRole, setSelectedRole] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: '', email: '', password: '', phone: '',
    restaurantName: '', organizationName: '', organizationType: 'ngo',
    street: '', city: '', state: '',
  });

  const handleRoleSelect = (role) => {
    setSelectedRole(role);
    setStep(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');
    setLoading(true);
    try {
      const payload = {
        name: form.name, email: form.email, password: form.password,
        role: selectedRole, phone: form.phone,
        address: { street: form.street, city: form.city, state: form.state, country: 'Nigeria' },
      };
      if (selectedRole === 'restaurant') {
        payload.restaurantName = form.restaurantName || form.name;
        payload.restaurantAddress = { street: form.street, city: form.city, state: form.state, country: 'Nigeria' };
      } else {
        payload.organizationName = form.organizationName || form.name;
        payload.organizationType = form.organizationType;
        payload.organizationAddress = { street: form.street, city: form.city, state: form.state, country: 'Nigeria' };
      }
      const data = await register(payload);
      toast.success(data.message || 'Registration successful!');
      const redirectMap = { restaurant: '/restaurant/dashboard', organization: '/organization/dashboard' };
      navigate(redirectMap[selectedRole]);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-emerald-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center shadow-glow">
              <span className="text-white font-bold text-xl">D</span>
            </div>
            <span className="font-display font-bold text-2xl text-gray-900 dark:text-white">DOKA <span className="text-primary-600">Donations</span></span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">
            {step === 1 ? 'Join DOKA Donations' : `Register as ${selectedRole === 'restaurant' ? 'Restaurant' : 'Organization'}`}
          </h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            {step === 1 ? 'Choose your account type to get started' : 'Fill in your details below'}
          </p>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-card border border-gray-100 dark:border-gray-800 p-8">
          {/* Step 1: Role Selection */}
          {step === 1 && (
            <div className="space-y-4">
              {roles.map((role) => (
                <button key={role.id} onClick={() => handleRoleSelect(role.id)}
                  className="w-full text-left p-4 rounded-xl border-2 border-gray-200 dark:border-gray-700 hover:border-primary-400 dark:hover:border-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-all duration-200 group">
                  <div className="flex items-center gap-4">
                    <span className="text-3xl">{role.icon}</span>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white group-hover:text-primary-700 dark:group-hover:text-primary-400">{role.label}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{role.desc}</p>
                    </div>
                    <span className="ml-auto text-gray-300 dark:text-gray-600 group-hover:text-primary-500">→</span>
                  </div>
                </button>
              ))}
              <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-4">
                Already have an account?{' '}
                <Link to="/login" className="text-primary-600 font-semibold hover:underline">Sign in</Link>
              </p>
            </div>
          )}

          {/* Step 2: Registration Form */}
          {step === 2 && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="form-label">Full Name *</label>
                <input type="text" className="form-input" placeholder="Your full name"
                  value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>

              {selectedRole === 'restaurant' ? (
                <div>
                  <label className="form-label">Restaurant Name *</label>
                  <input type="text" className="form-input" placeholder="e.g. Emeka's Kitchen"
                    value={form.restaurantName} onChange={(e) => setForm({ ...form, restaurantName: e.target.value })} />
                </div>
              ) : (
                <>
                  <div>
                    <label className="form-label">Organization Name *</label>
                    <input type="text" className="form-input" placeholder="e.g. Hope Foundation"
                      value={form.organizationName} onChange={(e) => setForm({ ...form, organizationName: e.target.value })} />
                  </div>
                  <div>
                    <label className="form-label">Organization Type *</label>
                    <select className="form-input" value={form.organizationType}
                      onChange={(e) => setForm({ ...form, organizationType: e.target.value })}>
                      {[['ngo','NGO'],['charity','Charity'],['food_bank','Food Bank'],['shelter','Shelter'],['community_center','Community Center'],['other','Other']].map(([v,l]) => (
                        <option key={v} value={v}>{l}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              <div>
                <label className="form-label">Email Address *</label>
                <input type="email" className="form-input" placeholder="you@example.com"
                  value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>

              <div>
                <label className="form-label">Phone Number</label>
                <input type="tel" className="form-input" placeholder="+234 800 000 0000"
                  value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="form-label">City *</label>
                  <input type="text" className="form-input" placeholder="Abuja"
                    value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} required />
                </div>
                <div>
                  <label className="form-label">State *</label>
                  <input type="text" className="form-input" placeholder="FCT"
                    value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} required />
                </div>
              </div>

              <div>
                <label className="form-label">Street Address</label>
                <input type="text" className="form-input" placeholder="12 Main Street"
                  value={form.street} onChange={(e) => setForm({ ...form, street: e.target.value })} />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="form-label mb-0">Password *</label>
                </div>
                <div className="relative">
                  <input type={showPassword ? 'text' : 'password'} className="form-input pr-10" placeholder="Min. 6 characters"
                    value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                    {showPassword ? <EyeSlashIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {selectedRole === 'restaurant' && (
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
                  <p className="text-xs text-yellow-700 dark:text-yellow-400">
                    ⏳ Restaurant accounts require admin approval before you can post listings.
                  </p>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setStep(1)} className="btn-secondary flex-1">← Back</button>
                <button type="submit" disabled={loading} className="btn-primary flex-1">
                  {loading ? <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Creating...
                  </span> : 'Create Account'}
                </button>
              </div>

              <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                Already have an account?{' '}
                <Link to="/login" className="text-primary-600 font-semibold hover:underline">Sign in</Link>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
