import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { EmptyState, Pagination, ConfirmDialog } from '../../components/common';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [deleteId, setDeleteId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchUsers = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 20 };
      if (search) params.search = search;
      if (roleFilter) params.role = roleFilter;
      const { data } = await adminAPI.getAllUsers(params);
      setUsers(data.data);
      setPagination(data.pagination);
    } catch { toast.error('Failed to load users'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchUsers(page); }, [page, roleFilter]);

  const toggleStatus = async (id) => {
    try {
      const { data } = await adminAPI.toggleUserStatus(id);
      setUsers(prev => prev.map(u => u._id === id ? {...u, isActive: data.data.isActive} : u));
      toast.success(`User ${data.data.isActive ? 'activated' : 'suspended'}`);
    } catch { toast.error('Action failed'); }
  };

  const deleteUser = async () => {
    setDeleting(true);
    try {
      await adminAPI.deleteUser(deleteId);
      toast.success('User deleted');
      setDeleteId(null);
      fetchUsers(page);
    } catch { toast.error('Delete failed'); }
    finally { setDeleting(false); }
  };

  const roleColor = { admin: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300', restaurant: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300', organization: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">User Management</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">View and manage all platform users</p>
      </div>

      {/* Search & filter */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <MagnifyingGlassIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input className="form-input pl-9" placeholder="Search by name or email..."
            value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetchUsers(1)} />
        </div>
        <select className="form-input w-40" value={roleFilter} onChange={e => { setRoleFilter(e.target.value); setPage(1); }}>
          <option value="">All Roles</option>
          <option value="restaurant">Restaurant</option>
          <option value="organization">Organization</option>
          <option value="admin">Admin</option>
        </select>
        <button onClick={() => fetchUsers(1)} className="btn-primary px-4">Search</button>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-400">Loading...</div>
        ) : users.length === 0 ? (
          <EmptyState icon="👥" title="No Users Found" description="No users match your search criteria." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                <tr>
                  {['User','Role','Status','Approved','Joined','Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {users.map(u => (
                  <tr key={u._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                          {u.avatar?.url ? <img src={u.avatar.url} alt="" className="w-full h-full object-cover" />
                            : <span className="text-sm font-semibold text-gray-600 dark:text-gray-400">{u.name.charAt(0).toUpperCase()}</span>}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{u.name}</p>
                          <p className="text-xs text-gray-500">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold capitalize ${roleColor[u.role] || ''}`}>{u.role}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${u.isActive ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'}`}>
                        {u.isActive ? 'Active' : 'Suspended'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs ${u.isApproved ? 'text-green-600' : 'text-yellow-600'}`}>{u.isApproved ? '✓ Yes' : '⏳ Pending'}</span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2">
                        {u.role !== 'admin' && (
                          <>
                            <button onClick={() => toggleStatus(u._id)}
                              className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${u.isActive ? 'bg-orange-100 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400 hover:bg-orange-200' : 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400 hover:bg-green-200'}`}>
                              {u.isActive ? 'Suspend' : 'Activate'}
                            </button>
                            <button onClick={() => setDeleteId(u._id)}
                              className="text-xs px-3 py-1.5 rounded-lg bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400 hover:bg-red-200 font-medium">
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />

      <ConfirmDialog isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={deleteUser}
        title="Delete User?" message="This will permanently delete the user and all their data. This cannot be undone."
        confirmLabel="Delete User" loading={deleting} />
    </div>
  );
}
