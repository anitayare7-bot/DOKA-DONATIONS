// Admin Donations page
import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { StatusBadge, Pagination, EmptyState } from '../../components/common';
import toast from 'react-hot-toast';

export default function AdminDonations() {
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [statusFilter, setStatusFilter] = useState('');

  const fetchDonations = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 20 };
      if (statusFilter) params.status = statusFilter;
      const { data } = await adminAPI.getAllDonations(params);
      setDonations(data.data);
      setPagination(data.pagination);
    } catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchDonations(page); }, [page, statusFilter]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">All Donations</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Monitor all donation requests across the platform</p>
      </div>

      <div className="flex gap-2 flex-wrap">
        {['','pending','approved','out_for_delivery','delivered','completed','rejected'].map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-colors ${statusFilter===s ? 'bg-primary-600 text-white border-primary-600' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-300 dark:border-gray-600'}`}>
            {s ? s.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase()) : 'All'}
          </button>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {loading ? <div className="p-8 text-center text-gray-400">Loading...</div>
        : donations.length === 0 ? <EmptyState icon="📋" title="No Donations" description="No donation requests match this filter." />
        : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                <tr>
                  {['Food','Restaurant','Organization','Status','Date'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {donations.map(d => (
                  <tr key={d._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <td className="px-4 py-3 font-medium text-gray-900 dark:text-white truncate max-w-[160px]">{d.foodListing?.title}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{d.restaurant?.restaurantName}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{d.organization?.organizationName}</td>
                    <td className="px-4 py-3"><StatusBadge status={d.status} /></td>
                    <td className="px-4 py-3 text-xs text-gray-500">{new Date(d.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />
    </div>
  );
}
