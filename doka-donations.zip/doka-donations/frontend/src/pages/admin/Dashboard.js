import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { adminAPI } from '../../services/api';
import { StatCard, LoadingPage } from '../../components/common';
import {
  UsersIcon, BuildingStorefrontIcon, ClipboardDocumentListIcon,
  CheckCircleIcon, FlagIcon, ScaleIcon, ClockIcon, ExclamationTriangleIcon
} from '@heroicons/react/24/outline';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.getStats()
      .then(res => setStats(res.data.data))
      .catch(() => toast.error('Failed to load stats'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingPage />;

  const chartData = stats?.monthlyTrends?.map(d => ({
    name: MONTHS[d._id.month - 1],
    donations: d.count,
  })) || [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Admin Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Platform overview and management</p>
      </div>

      {/* Alert for pending restaurants */}
      {stats?.pendingRestaurants > 0 && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-xl p-4 flex items-center gap-3">
          <ExclamationTriangleIcon className="w-5 h-5 text-yellow-600 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-300">
              {stats.pendingRestaurants} restaurant(s) awaiting approval
            </p>
          </div>
          <Link to="/admin/restaurants" className="text-sm text-yellow-700 dark:text-yellow-400 font-semibold hover:underline">Review →</Link>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Users" value={stats?.totalUsers || 0} icon={UsersIcon} color="blue" />
        <StatCard title="Restaurants" value={stats?.totalRestaurants || 0} icon={BuildingStorefrontIcon} color="orange" subtitle={`${stats?.pendingRestaurants || 0} pending`} />
        <StatCard title="Organizations" value={stats?.totalOrganizations || 0} icon={UsersIcon} color="purple" />
        <StatCard title="Total Donations" value={stats?.totalRequests || 0} icon={ClipboardDocumentListIcon} color="green" />
        <StatCard title="Completed" value={stats?.completedDonations || 0} icon={CheckCircleIcon} color="teal" />
        <StatCard title="Active Listings" value={stats?.activeListings || 0} icon={ClockIcon} color="blue" />
        <StatCard title="Open Reports" value={stats?.openReports || 0} icon={FlagIcon} color="red" />
        <StatCard title="Food Saved" value={`${stats?.totalFoodSavedKg || 0}kg`} icon={ScaleIcon} color="green" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Monthly chart */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white mb-6">Monthly Completed Donations</h2>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip contentStyle={{ borderRadius:'10px', border:'none', boxShadow:'0 4px 20px rgba(0,0,0,0.1)' }} />
                <Bar dataKey="donations" name="Donations" fill="#16a34a" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">No data yet</div>
          )}
        </div>

        {/* Quick links */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { to:'/admin/restaurants', icon:'🏪', label:'Review Restaurants', color:'bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400' },
              { to:'/admin/users', icon:'👥', label:'Manage Users', color:'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400' },
              { to:'/admin/donations', icon:'🤝', label:'All Donations', color:'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400' },
              { to:'/admin/reports', icon:'🚩', label:'Open Reports', color:'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400' },
              { to:'/admin/announcements', icon:'📢', label:'Announcements', color:'bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400' },
            ].map(item => (
              <Link key={item.to} to={item.to}
                className={`${item.color} p-4 rounded-xl flex flex-col items-center gap-2 text-center hover:opacity-80 transition-opacity`}>
                <span className="text-2xl">{item.icon}</span>
                <span className="text-xs font-semibold">{item.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
