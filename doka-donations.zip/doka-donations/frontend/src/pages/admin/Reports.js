import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { EmptyState, Pagination, Modal } from '../../components/common';
import toast from 'react-hot-toast';

const STATUS_COLORS = { open: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300', under_review: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300', resolved: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300', dismissed: 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300' };

export default function AdminReports() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [statusFilter, setStatusFilter] = useState('');
  const [actionReport, setActionReport] = useState(null);
  const [form, setForm] = useState({ status: 'resolved', adminNote: '' });
  const [saving, setSaving] = useState(false);

  const fetchReports = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 10 };
      if (statusFilter) params.status = statusFilter;
      const { data } = await adminAPI.getReports(params);
      setReports(data.data);
      setPagination(data.pagination);
    } catch { toast.error('Failed to load reports'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchReports(page); }, [page, statusFilter]);

  const updateReport = async () => {
    setSaving(true);
    try {
      await adminAPI.updateReport(actionReport._id, form);
      toast.success('Report updated!');
      setActionReport(null);
      fetchReports(page);
    } catch { toast.error('Action failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Reports & Issues</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Manage user-submitted reports and issues</p>
      </div>

      <div className="flex gap-2 flex-wrap">
        {['','open','under_review','resolved','dismissed'].map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-colors ${statusFilter===s ? 'bg-primary-600 text-white border-primary-600' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-300 dark:border-gray-600'}`}>
            {s ? s.replace('_',' ').replace(/\b\w/g,l=>l.toUpperCase()) : 'All'}
          </button>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {loading ? <div className="p-8 text-center text-gray-400">Loading...</div>
        : reports.length === 0 ? <EmptyState icon="🚩" title="No Reports" description="No reports match this filter." />
        : (
          <div className="divide-y divide-gray-100 dark:divide-gray-800">
            {reports.map(r => (
              <div key={r._id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${STATUS_COLORS[r.status]}`}>
                        {r.status.replace('_',' ').replace(/\b\w/g,l=>l.toUpperCase())}
                      </span>
                      <span className="text-xs bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 px-2 py-0.5 rounded-full capitalize">{r.type.replace('_',' ')}</span>
                    </div>
                    <p className="font-semibold text-gray-900 dark:text-white">{r.subject}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{r.description.slice(0,120)}...</p>
                    <p className="text-xs text-gray-400 mt-1">by {r.reportedBy?.name} · {new Date(r.createdAt).toLocaleDateString()}</p>
                  </div>
                  <button onClick={() => { setActionReport(r); setForm({ status: r.status, adminNote: r.adminNote || '' }); }}
                    className="btn-secondary text-xs px-3 py-1.5 flex-shrink-0">Review</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />

      <Modal isOpen={!!actionReport} onClose={() => setActionReport(null)} title="Review Report" size="md">
        {actionReport && (
          <div className="space-y-4">
            <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p className="font-semibold text-gray-900 dark:text-white">{actionReport.subject}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{actionReport.description}</p>
            </div>
            <div>
              <label className="form-label">Update Status</label>
              <select className="form-input" value={form.status} onChange={e => setForm({...form, status: e.target.value})}>
                <option value="open">Open</option>
                <option value="under_review">Under Review</option>
                <option value="resolved">Resolved</option>
                <option value="dismissed">Dismissed</option>
              </select>
            </div>
            <div>
              <label className="form-label">Admin Note</label>
              <textarea className="form-input resize-none" rows={3} value={form.adminNote} onChange={e => setForm({...form, adminNote: e.target.value})} placeholder="Add internal note..." />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setActionReport(null)} className="flex-1 btn-secondary">Cancel</button>
              <button onClick={updateReport} disabled={saving} className="flex-1 btn-primary">
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
