import React, { useState } from 'react';
import { adminAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function AdminAnnouncements() {
  const [form, setForm] = useState({ title: '', message: '', targetRole: '' });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      const { data } = await adminAPI.sendAnnouncement(form);
      toast.success(data.message);
      setSent(true);
      setForm({ title: '', message: '', targetRole: '' });
      setTimeout(() => setSent(false), 4000);
    } catch { toast.error('Failed to send announcement'); }
    finally { setSending(false); }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Send Announcement</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Send platform-wide notifications to users</p>
      </div>

      {sent && (
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-4">
          <p className="text-sm font-semibold text-green-700 dark:text-green-400">✅ Announcement sent successfully!</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800 space-y-4">
        <div>
          <label className="form-label">Target Audience</label>
          <select className="form-input" value={form.targetRole} onChange={e => setForm({...form, targetRole: e.target.value})}>
            <option value="">All Users</option>
            <option value="restaurant">Restaurants Only</option>
            <option value="organization">Organizations Only</option>
          </select>
        </div>
        <div>
          <label className="form-label">Announcement Title *</label>
          <input className="form-input" placeholder="e.g. Platform Maintenance Notice"
            value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
        </div>
        <div>
          <label className="form-label">Message *</label>
          <textarea className="form-input resize-none" rows={5}
            placeholder="Write your announcement message here..."
            value={form.message} onChange={e => setForm({...form, message: e.target.value})} required />
        </div>

        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
          <p className="text-sm text-blue-700 dark:text-blue-400">
            📢 This will send an in-app notification to{' '}
            <strong>{form.targetRole ? form.targetRole + 's' : 'all users'}</strong>.
            Recipients will see this in their notifications panel.
          </p>
        </div>

        <button type="submit" disabled={sending} className="w-full btn-primary py-3 gap-2">
          {sending ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Sending...
            </span>
          ) : '📢 Send Announcement'}
        </button>
      </form>
    </div>
  );
}
