import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { EmptyState, Modal } from '../../components/common';
import toast from 'react-hot-toast';

export default function AdminRestaurants() {
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionModal, setActionModal] = useState(null); // { restaurant, action }
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchPending = async () => {
    setLoading(true);
    try {
      const { data } = await adminAPI.getPendingRestaurants();
      setRestaurants(data.data);
    } catch { toast.error('Failed to load restaurants'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchPending(); }, []);

  const handleAction = async () => {
    if (!actionModal) return;
    setSaving(true);
    try {
      await adminAPI.updateRestaurantApproval(actionModal.restaurant._id, {
        status: actionModal.action, note
      });
      toast.success(`Restaurant ${actionModal.action}!`);
      setActionModal(null);
      setNote('');
      fetchPending();
    } catch { toast.error('Action failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Restaurant Applications</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Review and approve restaurant account applications</p>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-400">Loading...</div>
        ) : restaurants.length === 0 ? (
          <EmptyState icon="🏪" title="No Pending Applications" description="All restaurant applications have been reviewed." />
        ) : (
          <div className="divide-y divide-gray-100 dark:divide-gray-800">
            {restaurants.map(r => (
              <div key={r._id} className="p-5 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-2xl">🏪</div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">{r.restaurantName}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Owner: {r.user?.name}</p>
                      <p className="text-xs text-gray-400 mt-0.5">📧 {r.user?.email}</p>
                      {r.user?.phone && <p className="text-xs text-gray-400">📞 {r.user.phone}</p>}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500 dark:text-gray-400">Applied</p>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{new Date(r.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
                {r.address && (
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                    📍 {[r.address.street, r.address.city, r.address.state].filter(Boolean).join(', ')}
                  </p>
                )}
                {r.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-300 mt-2 italic">"{r.description}"</p>
                )}
                <div className="flex gap-3 mt-4">
                  <button onClick={() => { setActionModal({ restaurant: r, action: 'approved' }); setNote(''); }}
                    className="btn-primary px-5 py-2 gap-2">✅ Approve</button>
                  <button onClick={() => { setActionModal({ restaurant: r, action: 'rejected' }); setNote(''); }}
                    className="btn-danger px-5 py-2 gap-2">❌ Reject</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal isOpen={!!actionModal} onClose={() => setActionModal(null)}
        title={actionModal?.action === 'approved' ? '✅ Approve Restaurant' : '❌ Reject Restaurant'} size="md">
        <div className="space-y-4">
          <p className="text-sm text-gray-600 dark:text-gray-300">
            {actionModal?.action === 'approved'
              ? `Approve "${actionModal?.restaurant?.restaurantName}"? They will be notified and can start posting food listings.`
              : `Reject "${actionModal?.restaurant?.restaurantName}"? Please provide a reason.`}
          </p>
          <div>
            <label className="form-label">{actionModal?.action === 'rejected' ? 'Rejection Reason *' : 'Note (optional)'}</label>
            <textarea className="form-input resize-none" rows={3}
              placeholder={actionModal?.action === 'rejected' ? 'Explain why this application is rejected...' : 'Approval message...'}
              value={note} onChange={e => setNote(e.target.value)} />
          </div>
          <div className="flex gap-3">
            <button onClick={() => setActionModal(null)} className="flex-1 btn-secondary">Cancel</button>
            <button onClick={handleAction} disabled={saving} className={`flex-1 ${actionModal?.action === 'approved' ? 'btn-primary' : 'btn-danger'}`}>
              {saving ? 'Processing...' : actionModal?.action === 'approved' ? 'Approve' : 'Reject'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
