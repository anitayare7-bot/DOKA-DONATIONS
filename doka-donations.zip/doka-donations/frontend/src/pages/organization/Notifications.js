import React, { useState, useEffect } from 'react';
import { notificationsAPI } from '../../services/api';
import { EmptyState, Pagination, LoadingPage } from '../../components/common';
import { BellIcon, CheckIcon, TrashIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [unreadOnly, setUnreadOnly] = useState(false);

  const fetchNotifications = async (p = 1) => {
    setLoading(true);
    try {
      const { data } = await notificationsAPI.getAll({ page: p, limit: 15, unreadOnly });
      setNotifications(data.data);
      setPagination(data.pagination || {});
    } catch { toast.error('Failed to load notifications'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchNotifications(page); }, [page, unreadOnly]);

  const markRead = async (id) => {
    try {
      await notificationsAPI.markRead(id);
      setNotifications(prev => prev.map(n => n._id === id ? {...n, isRead: true} : n));
    } catch {}
  };

  const markAllRead = async () => {
    try {
      await notificationsAPI.markAllRead();
      setNotifications(prev => prev.map(n => ({...n, isRead: true})));
      toast.success('All marked as read');
    } catch {}
  };

  const deleteNotif = async (id) => {
    try {
      await notificationsAPI.delete(id);
      setNotifications(prev => prev.filter(n => n._id !== id));
    } catch {}
  };

  const typeIcon = (type) => {
    const icons = {
      donation_request: '📬', request_approved: '✅', request_rejected: '❌',
      out_for_delivery: '🚚', delivered: '📦', receipt_confirmed: '🎉',
      new_food_listing: '🍽️', listing_expiring: '⚡', account_approved: '✅',
      account_rejected: '❌', account_suspended: '🚫', system_announcement: '📢',
      review_received: '⭐',
    };
    return icons[type] || '🔔';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Notifications</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Stay updated on your activity</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={unreadOnly} onChange={e=>setUnreadOnly(e.target.checked)} className="w-4 h-4 rounded text-primary-600" />
            <span className="text-sm text-gray-600 dark:text-gray-400">Unread only</span>
          </label>
          <button onClick={markAllRead} className="btn-secondary text-sm gap-2">
            <CheckIcon className="w-4 h-4" /> Mark all read
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center"><div className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin mx-auto" /></div>
        ) : notifications.length === 0 ? (
          <EmptyState icon="🔔" title="No Notifications" description="You're all caught up! Notifications about your activity will appear here." />
        ) : (
          <div className="divide-y divide-gray-100 dark:divide-gray-800">
            {notifications.map(n => (
              <div key={n._id} className={`p-4 flex items-start gap-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors ${!n.isRead ? 'bg-primary-50/40 dark:bg-primary-900/10' : ''}`}>
                <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-xl flex-shrink-0">
                  {typeIcon(n.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className={`text-sm font-semibold ${!n.isRead ? 'text-gray-900 dark:text-white' : 'text-gray-700 dark:text-gray-300'}`}>{n.title}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{n.message}</p>
                    </div>
                    {!n.isRead && <div className="w-2 h-2 bg-primary-600 rounded-full flex-shrink-0 mt-1.5" />}
                  </div>
                  <p className="text-xs text-gray-400 dark:text-gray-500 mt-1.5">
                    {new Date(n.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {!n.isRead && (
                    <button onClick={() => markRead(n._id)} className="p-1.5 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/20 text-green-500 transition-colors" title="Mark as read">
                      <CheckIcon className="w-4 h-4" />
                    </button>
                  )}
                  <button onClick={() => deleteNotif(n._id)} className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/20 text-red-400 transition-colors" title="Delete">
                    <TrashIcon className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />
    </div>
  );
}
