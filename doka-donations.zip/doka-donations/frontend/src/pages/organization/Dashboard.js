import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { analyticsAPI, donationRequestsAPI } from '../../services/api';
import { StatCard, StatusBadge, LoadingPage } from '../../components/common';
import { MagnifyingGlassIcon, ClipboardDocumentListIcon, CheckCircleIcon, ScaleIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function OrgDashboard() {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState(null);
  const [recentRequests, setRecentRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [analyticsRes, requestsRes] = await Promise.all([
          analyticsAPI.getOrganizationAnalytics(),
          donationRequestsAPI.getOrganizationRequests({ limit: 5 }),
        ]);
        setAnalytics(analyticsRes.data.data);
        setRecentRequests(requestsRes.data.data);
      } catch { toast.error('Failed to load dashboard'); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  if (loading) return <LoadingPage />;

  const chartData = analytics?.monthlyReceived?.map(d => ({
    name: MONTHS[d._id.month - 1],
    received: d.count,
    weight: parseFloat((d.weightKg || 0).toFixed(1)),
  })) || [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">
            Welcome, {user?.name?.split(' ')[0]}! 🌿
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Browse available food donations for your organization</p>
        </div>
        <Link to="/organization/browse" className="btn-primary gap-2">
          <MagnifyingGlassIcon className="w-4 h-4" />
          Browse Food Donations
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Requests" value={analytics?.overview?.totalRequests || 0} icon={ClipboardDocumentListIcon} color="blue" />
        <StatCard title="Active Donations" value={analytics?.overview?.activeRequests || 0} icon={MagnifyingGlassIcon} color="orange" subtitle="In progress" />
        <StatCard title="Completed" value={analytics?.overview?.completedDonations || 0} icon={CheckCircleIcon} color="green" />
        <StatCard title="Food Received" value={`${analytics?.overview?.totalFoodReceivedKg || 0}kg`} icon={ScaleIcon} color="teal" subtitle={`${analytics?.overview?.successRate || 0}% success rate`} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-bold text-gray-900 dark:text-white">Monthly Donations Received</h2>
            <span className="text-xs text-gray-500 dark:text-gray-400">Last 6 months</span>
          </div>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip contentStyle={{ borderRadius:'10px', border:'none', boxShadow:'0 4px 20px rgba(0,0,0,0.1)' }} />
                <Line type="monotone" dataKey="received" name="Donations" stroke="#16a34a" strokeWidth={2} dot={{ fill: '#16a34a' }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">
              No donation history yet. Browse and request food donations!
            </div>
          )}
        </div>

        {/* Quick actions */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Link to="/organization/browse" className="flex items-center gap-3 p-3 bg-primary-50 dark:bg-primary-900/20 rounded-xl hover:bg-primary-100 dark:hover:bg-primary-900/30 transition-colors group">
              <span className="text-2xl">🔍</span>
              <div>
                <p className="text-sm font-semibold text-primary-700 dark:text-primary-400">Browse Available Food</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Find donations near you</p>
              </div>
              <ArrowRightIcon className="w-4 h-4 text-primary-600 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
            <Link to="/organization/donations" className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors group">
              <span className="text-2xl">📋</span>
              <div>
                <p className="text-sm font-semibold text-blue-700 dark:text-blue-400">Track My Requests</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Monitor donation status</p>
              </div>
              <ArrowRightIcon className="w-4 h-4 text-blue-600 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
          </div>
        </div>
      </div>

      {/* Recent requests */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-gray-800">
          <h2 className="font-bold text-gray-900 dark:text-white">Recent Requests</h2>
          <Link to="/organization/donations" className="text-sm text-primary-600 hover:underline flex items-center gap-1">
            View all <ArrowRightIcon className="w-3.5 h-3.5" />
          </Link>
        </div>
        <div className="divide-y divide-gray-100 dark:divide-gray-800">
          {recentRequests.length === 0 ? (
            <div className="p-8 text-center text-gray-400 text-sm">No requests yet. Browse food donations to get started!</div>
          ) : (
            recentRequests.map(req => (
              <div key={req._id} className="p-4 flex items-center gap-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-gray-100 dark:bg-gray-800 overflow-hidden flex-shrink-0">
                  {req.foodListing?.images?.[0]?.url ? (
                    <img src={req.foodListing.images[0].url} alt="" className="w-full h-full object-cover" />
                  ) : <div className="w-full h-full flex items-center justify-center">🍽️</div>}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">{req.foodListing?.title || 'Food Listing'}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{req.restaurant?.restaurantName}</p>
                </div>
                <StatusBadge status={req.status} />
                <Link to={`/organization/donations/${req._id}`} className="text-xs text-primary-600 hover:underline">View →</Link>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
