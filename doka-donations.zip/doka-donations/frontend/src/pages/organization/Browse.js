import React, { useState, useEffect, useCallback } from 'react';
import { foodListingsAPI, donationRequestsAPI, organizationAPI } from '../../services/api';
import { FoodCard, Modal, EmptyState, Pagination, LoadingPage } from '../../components/common';
import { MagnifyingGlassIcon, FunnelIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const CATEGORIES = ['','cooked_meals','raw_produce','baked_goods','beverages','packaged_food','dairy','meat_poultry','seafood','grains_cereals','fruits_vegetables','other'];

export default function OrgBrowse() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [city, setCity] = useState('');
  const [urgentOnly, setUrgentOnly] = useState(false);
  const [requestModal, setRequestModal] = useState(null);
  const [orgProfile, setOrgProfile] = useState(null);
  const [requestNote, setRequestNote] = useState('');
  const [requesting, setRequesting] = useState(false);

  // Load org profile for delivery address
  useEffect(() => {
    organizationAPI.getProfile().then(res => setOrgProfile(res.data.data)).catch(() => {});
  }, []);

  const fetchListings = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 12 };
      if (search) params.search = search;
      if (category) params.category = category;
      if (city) params.city = city;
      if (urgentOnly) params.urgent = 'true';
      const { data } = await foodListingsAPI.getAll(params);
      setListings(data.data);
      setPagination(data.pagination);
    } catch { toast.error('Failed to load listings'); }
    finally { setLoading(false); }
  }, [search, category, city, urgentOnly]);

  useEffect(() => { fetchListings(page); }, [page, category, city, urgentOnly]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchListings(1);
  };

  const handleRequest = async () => {
    if (!requestModal) return;
    setRequesting(true);
    try {
      await donationRequestsAPI.create({
        foodListingId: requestModal._id,
        requestNote,
        deliveryAddress: orgProfile?.address,
      });
      toast.success('Donation request submitted!');
      setRequestModal(null);
      setRequestNote('');
      fetchListings(page);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Request failed');
    } finally { setRequesting(false); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Browse Food Donations</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Find available food donations from restaurants near you</p>
      </div>

      {/* Search & Filters */}
      <div className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-card border border-gray-100 dark:border-gray-800">
        <form onSubmit={handleSearch} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative sm:col-span-2 lg:col-span-1">
            <MagnifyingGlassIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input className="form-input pl-9" placeholder="Search food..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="form-input" value={category} onChange={e => { setCategory(e.target.value); setPage(1); }}>
            <option value="">All Categories</option>
            {CATEGORIES.filter(Boolean).map(c => (
              <option key={c} value={c}>{c.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())}</option>
            ))}
          </select>
          <input className="form-input" placeholder="City / Location"
            value={city} onChange={e => setCity(e.target.value)} />
          <div className="flex gap-3 items-center">
            <label className="flex items-center gap-2 cursor-pointer flex-1">
              <input type="checkbox" checked={urgentOnly} onChange={e => { setUrgentOnly(e.target.checked); setPage(1); }} className="w-4 h-4 rounded text-primary-600" />
              <span className="text-sm text-gray-600 dark:text-gray-400">⚡ Urgent only</span>
            </label>
            <button type="submit" className="btn-primary px-4 py-2 gap-2">
              <FunnelIcon className="w-4 h-4" /> Search
            </button>
          </div>
        </form>
      </div>

      {/* Results */}
      {loading ? (
        <LoadingPage />
      ) : listings.length === 0 ? (
        <EmptyState icon="🔍" title="No Food Donations Found" description="Try adjusting your filters or check back later for new listings." />
      ) : (
        <>
          <p className="text-sm text-gray-500 dark:text-gray-400">{pagination.total || 0} donations available</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {listings.map(listing => (
              <FoodCard key={listing._id} listing={listing} onRequest={setRequestModal} showRequestButton />
            ))}
          </div>
          <Pagination currentPage={page} totalPages={pagination.pages || 1} onPageChange={setPage} />
        </>
      )}

      {/* Request Modal */}
      <Modal isOpen={!!requestModal} onClose={() => setRequestModal(null)} title="Request Food Donation" size="md">
        {requestModal && (
          <div className="space-y-4">
            <div className="flex gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl">
              <div className="w-14 h-14 rounded-lg bg-gray-200 dark:bg-gray-700 overflow-hidden flex-shrink-0">
                {requestModal.images?.[0]?.url ? (
                  <img src={requestModal.images[0].url} alt="" className="w-full h-full object-cover" />
                ) : <div className="w-full h-full flex items-center justify-center text-2xl">🍽️</div>}
              </div>
              <div>
                <p className="font-semibold text-gray-900 dark:text-white">{requestModal.title}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{requestModal.quantity?.amount} {requestModal.quantity?.unit}</p>
                <p className="text-xs text-gray-400 mt-0.5">from {requestModal.restaurant?.restaurantName}</p>
              </div>
            </div>

            {orgProfile?.address && (
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-1">Delivery to your registered address:</p>
                <p className="text-sm text-blue-600 dark:text-blue-300">
                  {[orgProfile.address.street, orgProfile.address.city, orgProfile.address.state].filter(Boolean).join(', ')}
                </p>
              </div>
            )}

            <div>
              <label className="form-label">Request Note (optional)</label>
              <textarea className="form-input resize-none" rows={3}
                placeholder="Tell the restaurant why you need this food and how many people you serve..."
                value={requestNote} onChange={e => setRequestNote(e.target.value)} />
            </div>

            <div className="flex gap-3">
              <button onClick={() => setRequestModal(null)} className="flex-1 btn-secondary">Cancel</button>
              <button onClick={handleRequest} disabled={requesting} className="flex-1 btn-primary">
                {requesting ? 'Submitting...' : '🤝 Submit Request'}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
