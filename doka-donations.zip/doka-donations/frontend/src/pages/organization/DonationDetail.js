import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { donationRequestsAPI } from '../../services/api';
import { StatusBadge, DeliveryTimeline, Modal, LoadingPage } from '../../components/common';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function OrgDonationDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [receiptNote, setReceiptNote] = useState('');
  const [rating, setRating] = useState(5);
  const [confirming, setConfirming] = useState(false);

  const load = async () => {
    try {
      const { data } = await donationRequestsAPI.getOne(id);
      setRequest(data.data);
    } catch { toast.error('Failed to load request'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [id]);

  const handleConfirmReceipt = async () => {
    setConfirming(true);
    try {
      await donationRequestsAPI.confirmReceipt(id, { receiptNote, rating });
      toast.success('Receipt confirmed! Donation completed 🎉');
      setShowConfirmModal(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Confirmation failed');
    } finally { setConfirming(false); }
  };

  if (loading) return <LoadingPage />;
  if (!request) return <div className="text-center py-20 text-gray-400">Request not found</div>;

  const { foodListing, restaurant, status, statusHistory, deliveryPersonName, deliveryPersonPhone, estimatedDeliveryTime } = request;

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/organization/donations')} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 transition-colors">
          <ArrowLeftIcon className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">Donation Request</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">#{id.slice(-8).toUpperCase()}</p>
        </div>
        <div className="ml-auto"><StatusBadge status={status} /></div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Food info */}
          <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
            <h2 className="font-bold text-gray-900 dark:text-white mb-4">Food Details</h2>
            <div className="flex gap-4">
              <div className="w-20 h-20 rounded-xl bg-gray-100 dark:bg-gray-800 overflow-hidden flex-shrink-0">
                {foodListing?.images?.[0]?.url
                  ? <img src={foodListing.images[0].url} alt="" className="w-full h-full object-cover" />
                  : <div className="w-full h-full flex items-center justify-center text-3xl">🍽️</div>}
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{foodListing?.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{foodListing?.description}</p>
                <div className="flex gap-4 mt-2 text-sm text-gray-600 dark:text-gray-400">
                  <span>📦 {foodListing?.quantity?.amount} {foodListing?.quantity?.unit}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Restaurant info */}
          <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
            <h2 className="font-bold text-gray-900 dark:text-white mb-4">Restaurant Information</h2>
            <div className="space-y-2 text-sm">
              <p><span className="text-gray-500 dark:text-gray-400">Name:</span> <span className="font-semibold text-gray-800 dark:text-gray-200 ml-2">{restaurant?.restaurantName}</span></p>
              <p><span className="text-gray-500 dark:text-gray-400">City:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{restaurant?.address?.city}</span></p>
              {restaurant?.contactPhone && <p><span className="text-gray-500 dark:text-gray-400">Phone:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{restaurant.contactPhone}</span></p>}
            </div>
          </div>

          {/* Delivery info */}
          {deliveryPersonName && (
            <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800">
              <h2 className="font-bold text-gray-900 dark:text-white mb-4">🚚 Delivery Information</h2>
              <div className="space-y-2 text-sm">
                <p><span className="text-gray-500">Delivery Person:</span> <span className="font-semibold text-gray-800 dark:text-gray-200 ml-2">{deliveryPersonName}</span></p>
                {deliveryPersonPhone && <p><span className="text-gray-500">Phone:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{deliveryPersonPhone}</span></p>}
                {estimatedDeliveryTime && <p><span className="text-gray-500">ETA:</span> <span className="ml-2 text-gray-700 dark:text-gray-300">{new Date(estimatedDeliveryTime).toLocaleString()}</span></p>}
              </div>
            </div>
          )}

          {/* Confirm Receipt action */}
          {status === 'delivered' && !request.receiptConfirmed && (
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-6">
              <h2 className="font-bold text-green-800 dark:text-green-300 mb-2">📦 Food Has Been Delivered!</h2>
              <p className="text-sm text-green-700 dark:text-green-400 mb-4">Please confirm receipt to complete this donation and help us track our impact.</p>
              <button onClick={() => setShowConfirmModal(true)} className="btn-primary bg-green-600 hover:bg-green-700">
                ✅ Confirm Receipt
              </button>
            </div>
          )}

          {status === 'completed' && (
            <div className="bg-primary-50 dark:bg-primary-900/20 border border-primary-200 dark:border-primary-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-2">🎉</div>
              <h2 className="font-bold text-primary-800 dark:text-primary-300">Donation Completed!</h2>
              <p className="text-sm text-primary-600 dark:text-primary-400 mt-1">Thank you for participating in DOKA Donations.</p>
            </div>
          )}
        </div>

        {/* Timeline */}
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-card border border-gray-100 dark:border-gray-800 h-fit">
          <h2 className="font-bold text-gray-900 dark:text-white mb-6">Delivery Timeline</h2>
          <DeliveryTimeline statusHistory={statusHistory} />
        </div>
      </div>

      {/* Confirm Receipt Modal */}
      <Modal isOpen={showConfirmModal} onClose={() => setShowConfirmModal(false)} title="Confirm Food Receipt" size="md">
        <div className="space-y-4">
          <p className="text-sm text-gray-600 dark:text-gray-300">Please confirm that you have received the food donation. This will complete the donation cycle.</p>
          <div>
            <label className="form-label">Rate this donation</label>
            <div className="flex gap-2">
              {[1,2,3,4,5].map(n => (
                <button key={n} type="button" onClick={() => setRating(n)}
                  className={`text-2xl transition-transform hover:scale-110 ${n <= rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}>
                  ★
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="form-label">Receipt Note (optional)</label>
            <textarea className="form-input resize-none" rows={3} placeholder="Any feedback about this donation..."
              value={receiptNote} onChange={e => setReceiptNote(e.target.value)} />
          </div>
          <div className="flex gap-3">
            <button onClick={() => setShowConfirmModal(false)} className="flex-1 btn-secondary">Cancel</button>
            <button onClick={handleConfirmReceipt} disabled={confirming} className="flex-1 btn-primary bg-green-600 hover:bg-green-700">
              {confirming ? 'Confirming...' : '✅ Confirm Receipt'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
