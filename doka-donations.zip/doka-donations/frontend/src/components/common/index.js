// components/common/index.js - All reusable UI components

import React from 'react';

// ─── Stat Card ───────────────────────────────────────────────────────────────
export const StatCard = ({ title, value, icon: Icon, color = 'green', subtitle, trend }) => {
  const colors = {
    green: 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400',
    blue: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
    orange: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400',
    purple: 'bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400',
    red: 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400',
    teal: 'bg-teal-50 dark:bg-teal-900/20 text-teal-600 dark:text-teal-400',
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl p-5 shadow-card border border-gray-100 dark:border-gray-800 card-hover">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white font-display">{value}</p>
          {subtitle && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>}
          {trend !== undefined && (
            <p className={`text-xs font-medium mt-1 ${trend >= 0 ? 'text-green-600' : 'text-red-500'}`}>
              {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}% this month
            </p>
          )}
        </div>
        {Icon && (
          <div className={`p-2.5 rounded-xl ${colors[color]}`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Status Badge ─────────────────────────────────────────────────────────────
export const StatusBadge = ({ status }) => {
  const config = {
    pending: { bg: 'bg-yellow-100 dark:bg-yellow-900/30', text: 'text-yellow-800 dark:text-yellow-300', label: 'Pending' },
    approved: { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-800 dark:text-blue-300', label: 'Approved' },
    out_for_delivery: { bg: 'bg-purple-100 dark:bg-purple-900/30', text: 'text-purple-800 dark:text-purple-300', label: 'Out for Delivery' },
    delivered: { bg: 'bg-teal-100 dark:bg-teal-900/30', text: 'text-teal-800 dark:text-teal-300', label: 'Delivered' },
    completed: { bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-800 dark:text-green-300', label: 'Completed' },
    rejected: { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-800 dark:text-red-300', label: 'Rejected' },
    cancelled: { bg: 'bg-gray-100 dark:bg-gray-700', text: 'text-gray-700 dark:text-gray-300', label: 'Cancelled' },
    available: { bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-800 dark:text-emerald-300', label: 'Available' },
    reserved: { bg: 'bg-indigo-100 dark:bg-indigo-900/30', text: 'text-indigo-800 dark:text-indigo-300', label: 'Reserved' },
    expired: { bg: 'bg-orange-100 dark:bg-orange-900/30', text: 'text-orange-800 dark:text-orange-300', label: 'Expired' },
  };
  const c = config[status] || config.cancelled;
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${c.bg} ${c.text}`}>
      {c.label}
    </span>
  );
};

// ─── Loading Spinner ──────────────────────────────────────────────────────────
export const Spinner = ({ size = 'md', className = '' }) => {
  const sizes = { sm: 'w-4 h-4 border-2', md: 'w-8 h-8 border-3', lg: 'w-12 h-12 border-4' };
  return (
    <div className={`${sizes[size]} border-primary-200 border-t-primary-600 rounded-full animate-spin ${className}`} />
  );
};

// ─── Loading Page ─────────────────────────────────────────────────────────────
export const LoadingPage = ({ message = 'Loading...' }) => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="flex flex-col items-center gap-4">
      <Spinner size="lg" />
      <p className="text-sm text-gray-500 dark:text-gray-400">{message}</p>
    </div>
  </div>
);

// ─── Empty State ──────────────────────────────────────────────────────────────
export const EmptyState = ({ icon, title, description, action }) => (
  <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
    {icon && <div className="text-5xl mb-4">{icon}</div>}
    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{title}</h3>
    {description && <p className="text-sm text-gray-500 dark:text-gray-400 mb-6 max-w-sm">{description}</p>}
    {action}
  </div>
);

// ─── Modal ────────────────────────────────────────────────────────────────────
export const Modal = ({ isOpen, onClose, title, children, size = 'md' }) => {
  if (!isOpen) return null;
  const sizes = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-2xl', '2xl': 'max-w-4xl' };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full ${sizes[size]} max-h-[90vh] overflow-y-auto animate-slide-up border border-gray-200 dark:border-gray-700`}>
        {title && (
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white font-display">{title}</h2>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 transition-colors">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
};

// ─── Page Header ─────────────────────────────────────────────────────────────
export const PageHeader = ({ title, subtitle, action }) => (
  <div className="flex items-start justify-between mb-6">
    <div>
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-display">{title}</h1>
      {subtitle && <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{subtitle}</p>}
    </div>
    {action && <div className="ml-4 flex-shrink-0">{action}</div>}
  </div>
);

// ─── Food Category Label ──────────────────────────────────────────────────────
export const CategoryBadge = ({ category }) => {
  const labels = {
    cooked_meals: '🍲 Cooked Meals',
    raw_produce: '🥬 Raw Produce',
    baked_goods: '🍞 Baked Goods',
    beverages: '🥤 Beverages',
    packaged_food: '📦 Packaged Food',
    dairy: '🧀 Dairy',
    meat_poultry: '🍗 Meat & Poultry',
    seafood: '🐟 Seafood',
    grains_cereals: '🌾 Grains & Cereals',
    fruits_vegetables: '🥝 Fruits & Vegetables',
    other: '🍴 Other',
  };
  return (
    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300">
      {labels[category] || category}
    </span>
  );
};

// ─── Confirmation Dialog ──────────────────────────────────────────────────────
export const ConfirmDialog = ({ isOpen, onClose, onConfirm, title, message, confirmLabel = 'Confirm', variant = 'danger', loading = false }) => (
  <Modal isOpen={isOpen} onClose={onClose} size="sm">
    <div className="text-center">
      <div className={`w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center ${variant === 'danger' ? 'bg-red-100 dark:bg-red-900/30' : 'bg-yellow-100 dark:bg-yellow-900/30'}`}>
        <span className="text-2xl">{variant === 'danger' ? '⚠️' : '❓'}</span>
      </div>
      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{title}</h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">{message}</p>
      <div className="flex gap-3">
        <button onClick={onClose} className="flex-1 btn-secondary" disabled={loading}>Cancel</button>
        <button
          onClick={onConfirm}
          disabled={loading}
          className={`flex-1 btn ${variant === 'danger' ? 'btn-danger' : 'btn-primary'}`}
        >
          {loading ? <Spinner size="sm" /> : confirmLabel}
        </button>
      </div>
    </div>
  </Modal>
);

// ─── Pagination ───────────────────────────────────────────────────────────────
export const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  if (totalPages <= 1) return null;
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);
  const visible = pages.filter(p => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1);

  return (
    <div className="flex items-center justify-center gap-1 mt-6">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className="px-3 py-1.5 rounded-lg text-sm border border-gray-300 dark:border-gray-600 disabled:opacity-40 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:cursor-not-allowed"
      >
        ← Prev
      </button>
      {visible.reduce((acc, page, idx) => {
        if (idx > 0 && page - visible[idx - 1] > 1) {
          acc.push(<span key={`dots-${page}`} className="px-2 text-gray-400">…</span>);
        }
        acc.push(
          <button
            key={page}
            onClick={() => onPageChange(page)}
            className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
              currentPage === page
                ? 'bg-primary-600 text-white'
                : 'border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300'
            }`}
          >
            {page}
          </button>
        );
        return acc;
      }, [])}
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="px-3 py-1.5 rounded-lg text-sm border border-gray-300 dark:border-gray-600 disabled:opacity-40 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:cursor-not-allowed"
      >
        Next →
      </button>
    </div>
  );
};

// ─── Food Card ────────────────────────────────────────────────────────────────
export const FoodCard = ({ listing, onRequest, showRequestButton = true }) => {
  const isExpiringSoon = new Date(listing.expiryTime) < new Date(Date.now() + 6 * 60 * 60 * 1000);
  const timeLeft = getTimeLeft(listing.expiryTime);

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-card border border-gray-100 dark:border-gray-800 overflow-hidden card-hover group">
      <div className="relative h-48 overflow-hidden bg-gray-100 dark:bg-gray-800">
        {listing.images?.[0]?.url ? (
          <img
            src={listing.images[0].url}
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-5xl opacity-30">🍽️</span>
          </div>
        )}
        {listing.isUrgent && (
          <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
            ⚡ URGENT
          </div>
        )}
        <div className="absolute top-2 right-2">
          <StatusBadge status={listing.status} />
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-semibold text-gray-900 dark:text-white text-sm leading-snug line-clamp-2">{listing.title}</h3>
        </div>
        <CategoryBadge category={listing.category} />

        <div className="mt-3 space-y-1.5 text-xs text-gray-500 dark:text-gray-400">
          <div className="flex items-center gap-1.5">
            <span>📦</span>
            <span>{listing.quantity?.amount} {listing.quantity?.unit}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span>📍</span>
            <span className="truncate">{listing.pickupLocation?.city || listing.restaurant?.address?.city}</span>
          </div>
          <div className={`flex items-center gap-1.5 ${isExpiringSoon ? 'text-red-500 font-semibold' : ''}`}>
            <span>⏰</span>
            <span>Expires {timeLeft}</span>
          </div>
        </div>

        {listing.dietaryInfo && (
          <div className="flex gap-1 mt-3 flex-wrap">
            {listing.dietaryInfo.isHalal && <span className="text-xs px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-full">Halal</span>}
            {listing.dietaryInfo.isVegetarian && <span className="text-xs px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 rounded-full">Vegetarian</span>}
            {listing.dietaryInfo.isVegan && <span className="text-xs px-2 py-0.5 bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400 rounded-full">Vegan</span>}
          </div>
        )}

        {showRequestButton && listing.status === 'available' && (
          <button
            onClick={() => onRequest(listing)}
            className="mt-4 w-full btn-primary text-sm py-2"
          >
            Request Donation
          </button>
        )}
      </div>
    </div>
  );
};

function getTimeLeft(expiryTime) {
  const diff = new Date(expiryTime) - new Date();
  if (diff < 0) return 'Expired';
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  if (hours >= 24) return `in ${Math.floor(hours / 24)} day(s)`;
  if (hours >= 1) return `in ${hours}h ${mins}m`;
  return `in ${mins} minutes`;
}

// ─── Delivery Timeline ────────────────────────────────────────────────────────
export const DeliveryTimeline = ({ statusHistory }) => {
  const steps = ['pending', 'approved', 'out_for_delivery', 'delivered', 'completed'];
  const stepLabels = {
    pending: 'Request Submitted',
    approved: 'Approved by Restaurant',
    out_for_delivery: 'Out for Delivery',
    delivered: 'Delivered',
    completed: 'Completed',
  };

  const completedSteps = (statusHistory || []).map(h => h.status);
  const currentStep = steps.findIndex(s => !completedSteps.includes(s));

  return (
    <div className="space-y-3">
      {steps.map((step, idx) => {
        const isCompleted = completedSteps.includes(step);
        const isCurrent = idx === currentStep;
        const historyEntry = (statusHistory || []).find(h => h.status === step);

        return (
          <div key={step} className="flex gap-3">
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                isCompleted ? 'bg-primary-600 text-white' : isCurrent ? 'bg-primary-100 dark:bg-primary-900 border-2 border-primary-600 text-primary-600' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'
              }`}>
                {isCompleted ? '✓' : idx + 1}
              </div>
              {idx < steps.length - 1 && (
                <div className={`w-0.5 h-6 mt-1 ${isCompleted ? 'bg-primary-600' : 'bg-gray-200 dark:bg-gray-700'}`} />
              )}
            </div>
            <div className="pb-4 flex-1">
              <p className={`text-sm font-medium ${isCompleted ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
                {stepLabels[step]}
              </p>
              {historyEntry?.note && (
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{historyEntry.note}</p>
              )}
              {historyEntry?.timestamp && (
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                  {new Date(historyEntry.timestamp).toLocaleString()}
                </p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
