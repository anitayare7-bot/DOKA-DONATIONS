import { useState, useEffect, useCallback } from 'react';
import { notificationsAPI } from '../services/api';

/**
 * Custom hook to poll unread notification count.
 * @param {number} interval - polling interval in ms (default 60000)
 */
export const useNotifications = (interval = 60000) => {
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchCount = useCallback(async () => {
    try {
      const { data } = await notificationsAPI.getAll({ unreadOnly: true, limit: 1 });
      setUnreadCount(data.unreadCount || 0);
    } catch {}
  }, []);

  const fetchAll = useCallback(async (params = {}) => {
    setLoading(true);
    try {
      const { data } = await notificationsAPI.getAll({ limit: 20, ...params });
      setNotifications(data.data || []);
      setUnreadCount(data.unreadCount || 0);
    } catch {}
    finally { setLoading(false); }
  }, []);

  const markRead = useCallback(async (id) => {
    await notificationsAPI.markRead(id);
    setNotifications(prev => prev.map(n => n._id === id ? { ...n, isRead: true } : n));
    setUnreadCount(prev => Math.max(0, prev - 1));
  }, []);

  const markAllRead = useCallback(async () => {
    await notificationsAPI.markAllRead();
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    setUnreadCount(0);
  }, []);

  useEffect(() => {
    fetchCount();
    const timer = setInterval(fetchCount, interval);
    return () => clearInterval(timer);
  }, [fetchCount, interval]);

  return { unreadCount, notifications, loading, fetchCount, fetchAll, markRead, markAllRead };
};

export default useNotifications;
