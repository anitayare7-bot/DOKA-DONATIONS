import { useState, useEffect } from 'react';

/**
 * Debounces a value by the given delay.
 * Useful for search inputs to avoid firing on every keystroke.
 * @param {any} value
 * @param {number} delay - ms to wait (default 400)
 */
export const useDebounce = (value, delay = 400) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
};

export default useDebounce;
