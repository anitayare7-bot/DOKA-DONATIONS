const express = require('express');
const router = express.Router();
const { getRestaurantAnalytics, getOrganizationAnalytics } = require('../controllers/analyticsController');
const { protect, authorize } = require('../middleware/auth');

router.get('/restaurant', protect, authorize('restaurant'), getRestaurantAnalytics);
router.get('/organization', protect, authorize('organization'), getOrganizationAnalytics);

module.exports = router;
