const express = require('express');
const router = express.Router();
const {
  getStats, getAllUsers, getPendingRestaurants, updateRestaurantApproval,
  toggleUserStatus, deleteUser, sendAnnouncement, getReports, updateReport, getAllDonations
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));

router.get('/stats', getStats);
router.get('/users', getAllUsers);
router.delete('/users/:id', deleteUser);
router.put('/users/:id/toggle-status', toggleUserStatus);
router.get('/restaurants/pending', getPendingRestaurants);
router.put('/restaurants/:id/approval', updateRestaurantApproval);
router.post('/announce', sendAnnouncement);
router.get('/reports', getReports);
router.put('/reports/:id', updateReport);
router.get('/donations', getAllDonations);

module.exports = router;
