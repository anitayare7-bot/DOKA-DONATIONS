const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect } = require('../middleware/auth');
const { uploadFoodImage, uploadProfileImage, deleteImage } = require('../config/cloudinary');

// Upload food image
router.post('/food-image', protect, uploadFoodImage.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) { res.status(400); throw new Error('No file uploaded'); }
  res.json({ success: true, url: req.file.path, publicId: req.file.filename });
}));

// Upload profile image
router.post('/profile-image', protect, uploadProfileImage.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) { res.status(400); throw new Error('No file uploaded'); }
  res.json({ success: true, url: req.file.path, publicId: req.file.filename });
}));

// Delete image
router.delete('/image/:publicId', protect, asyncHandler(async (req, res) => {
  await deleteImage(decodeURIComponent(req.params.publicId));
  res.json({ success: true, message: 'Image deleted' });
}));

module.exports = router;
