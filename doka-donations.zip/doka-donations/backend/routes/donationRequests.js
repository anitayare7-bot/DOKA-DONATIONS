const express = require('express');
const router = express.Router();
const {
  createDonationRequest, getRestaurantDonationRequests,
  getOrganizationDonationRequests, updateDonationStatus, confirmReceipt, getDonationRequest
} = require('../controllers/donationRequestController');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, authorize('organization'), createDonationRequest);
router.get('/restaurant', protect, authorize('restaurant'), getRestaurantDonationRequests);
router.get('/organization', protect, authorize('organization'), getOrganizationDonationRequests);
router.get('/:id', protect, getDonationRequest);
router.put('/:id/status', protect, authorize('restaurant'), updateDonationStatus);
router.put('/:id/confirm-receipt', protect, authorize('organization'), confirmReceipt);

module.exports = router;
