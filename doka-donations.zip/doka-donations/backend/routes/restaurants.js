const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const Restaurant = require('../models/Restaurant');
const { protect, authorize } = require('../middleware/auth');
const { uploadProfileImage } = require('../config/cloudinary');

// Get own restaurant profile
router.get('/profile', protect, authorize('restaurant'), asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findOne({ user: req.user._id }).populate('user', 'name email phone');
  if (!restaurant) { res.status(404); throw new Error('Restaurant not found'); }
  res.json({ success: true, data: restaurant });
}));

// Update restaurant profile
router.put('/profile', protect, authorize('restaurant'), asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findOneAndUpdate(
    { user: req.user._id }, req.body, { new: true, runValidators: true }
  );
  if (!restaurant) { res.status(404); throw new Error('Restaurant not found'); }
  res.json({ success: true, data: restaurant, message: 'Profile updated' });
}));

// Update restaurant logo
router.put('/logo', protect, authorize('restaurant'), uploadProfileImage.single('logo'), asyncHandler(async (req, res) => {
  if (!req.file) { res.status(400); throw new Error('No file uploaded'); }
  const restaurant = await Restaurant.findOneAndUpdate(
    { user: req.user._id },
    { logo: { url: req.file.path, publicId: req.file.filename } },
    { new: true }
  );
  res.json({ success: true, data: restaurant });
}));

// Public - get restaurant by id
router.get('/:id', asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findById(req.params.id).populate('user', 'name email');
  if (!restaurant) { res.status(404); throw new Error('Restaurant not found'); }
  res.json({ success: true, data: restaurant });
}));

// Get all approved restaurants (public)
router.get('/', asyncHandler(async (req, res) => {
  const restaurants = await Restaurant.find({ approvalStatus: 'approved' })
    .populate('user', 'name email')
    .select('restaurantName address logo cuisine rating completedDonations');
  res.json({ success: true, data: restaurants });
}));

module.exports = router;
