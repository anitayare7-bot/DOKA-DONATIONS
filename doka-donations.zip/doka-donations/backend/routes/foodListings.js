const express = require('express');
const router = express.Router();
const {
  getFoodListings, getMyFoodListings, getFoodListing,
  createFoodListing, updateFoodListing, deleteFoodListing, removeFoodImage
} = require('../controllers/foodListingController');
const { protect, authorize, requireApproval } = require('../middleware/auth');
const { uploadFoodImage } = require('../config/cloudinary');

router.get('/', protect, getFoodListings);
router.get('/mine', protect, authorize('restaurant'), getMyFoodListings);
router.get('/:id', protect, getFoodListing);

router.post('/',
  protect, authorize('restaurant'), requireApproval,
  uploadFoodImage.array('images', 5),
  createFoodListing
);

router.put('/:id',
  protect, authorize('restaurant', 'admin'),
  uploadFoodImage.array('images', 5),
  updateFoodListing
);

router.delete('/:id', protect, authorize('restaurant', 'admin'), deleteFoodListing);
router.delete('/:id/images/:publicId', protect, authorize('restaurant'), removeFoodImage);

module.exports = router;
