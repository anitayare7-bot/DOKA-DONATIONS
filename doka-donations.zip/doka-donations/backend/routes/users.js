// routes/users.js
const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const { uploadProfileImage } = require('../config/cloudinary');

router.put('/profile', protect, asyncHandler(async (req, res) => {
  const { name, phone, address } = req.body;
  const user = await User.findByIdAndUpdate(req.user._id, { name, phone, address }, { new: true, runValidators: true });
  res.json({ success: true, data: user, message: 'Profile updated' });
}));

router.put('/avatar', protect, uploadProfileImage.single('avatar'), asyncHandler(async (req, res) => {
  if (!req.file) { res.status(400); throw new Error('No file uploaded'); }
  const user = await User.findByIdAndUpdate(req.user._id, {
    avatar: { url: req.file.path, publicId: req.file.filename }
  }, { new: true });
  res.json({ success: true, data: user });
}));

module.exports = router;
