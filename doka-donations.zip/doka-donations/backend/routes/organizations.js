const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const Organization = require('../models/Organization');
const { protect, authorize } = require('../middleware/auth');
const { uploadProfileImage } = require('../config/cloudinary');

router.get('/profile', protect, authorize('organization'), asyncHandler(async (req, res) => {
  const org = await Organization.findOne({ user: req.user._id }).populate('user', 'name email phone');
  if (!org) { res.status(404); throw new Error('Organization not found'); }
  res.json({ success: true, data: org });
}));

router.put('/profile', protect, authorize('organization'), asyncHandler(async (req, res) => {
  const org = await Organization.findOneAndUpdate(
    { user: req.user._id }, req.body, { new: true, runValidators: true }
  );
  if (!org) { res.status(404); throw new Error('Organization not found'); }
  res.json({ success: true, data: org, message: 'Profile updated' });
}));

router.put('/logo', protect, authorize('organization'), uploadProfileImage.single('logo'), asyncHandler(async (req, res) => {
  if (!req.file) { res.status(400); throw new Error('No file uploaded'); }
  const org = await Organization.findOneAndUpdate(
    { user: req.user._id },
    { logo: { url: req.file.path, publicId: req.file.filename } },
    { new: true }
  );
  res.json({ success: true, data: org });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const org = await Organization.findById(req.params.id).populate('user', 'name email');
  if (!org) { res.status(404); throw new Error('Organization not found'); }
  res.json({ success: true, data: org });
}));

module.exports = router;
