const asyncHandler = require('express-async-handler');
const DonationRequest = require('../models/DonationRequest');
const FoodListing = require('../models/FoodListing');
const Restaurant = require('../models/Restaurant');
const Organization = require('../models/Organization');

// @desc    Get restaurant analytics
// @route   GET /api/analytics/restaurant
// @access  Private (restaurant)
const getRestaurantAnalytics = asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findOne({ user: req.user._id });
  if (!restaurant) {
    res.status(404);
    throw new Error('Restaurant not found');
  }

  const restaurantId = restaurant._id;

  const [
    totalListings, activeListings, completedDonations,
    pendingRequests, totalRequestsCount,
  ] = await Promise.all([
    FoodListing.countDocuments({ restaurant: restaurantId }),
    FoodListing.countDocuments({ restaurant: restaurantId, status: 'available' }),
    DonationRequest.countDocuments({ restaurant: restaurantId, status: 'completed' }),
    DonationRequest.countDocuments({ restaurant: restaurantId, status: 'pending' }),
    DonationRequest.countDocuments({ restaurant: restaurantId }),
  ]);

  // Monthly donations (last 6 months)
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  const monthlyDonations = await DonationRequest.aggregate([
    { $match: { restaurant: restaurantId, status: 'completed', createdAt: { $gte: sixMonthsAgo } } },
    {
      $group: {
        _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
        count: { $sum: 1 },
        weightKg: { $sum: '$estimatedWeightKg' },
      },
    },
    { $sort: { '_id.year': 1, '_id.month': 1 } },
  ]);

  // Category breakdown
  const categoryBreakdown = await FoodListing.aggregate([
    { $match: { restaurant: restaurantId } },
    { $group: { _id: '$category', count: { $sum: 1 } } },
    { $sort: { count: -1 } },
  ]);

  // Request status breakdown
  const statusBreakdown = await DonationRequest.aggregate([
    { $match: { restaurant: restaurantId } },
    { $group: { _id: '$status', count: { $sum: 1 } } },
  ]);

  res.json({
    success: true,
    data: {
      overview: {
        totalListings,
        activeListings,
        completedDonations,
        pendingRequests,
        totalRequestsCount,
        totalFoodSavedKg: restaurant.totalFoodSaved,
        acceptanceRate: totalRequestsCount > 0 ? ((completedDonations / totalRequestsCount) * 100).toFixed(1) : 0,
      },
      monthlyDonations,
      categoryBreakdown,
      statusBreakdown,
    },
  });
});

// @desc    Get organization analytics
// @route   GET /api/analytics/organization
// @access  Private (organization)
const getOrganizationAnalytics = asyncHandler(async (req, res) => {
  const organization = await Organization.findOne({ user: req.user._id });
  if (!organization) {
    res.status(404);
    throw new Error('Organization not found');
  }

  const orgId = organization._id;

  const [totalRequests, completedDonations, pendingRequests, activeRequests] = await Promise.all([
    DonationRequest.countDocuments({ organization: orgId }),
    DonationRequest.countDocuments({ organization: orgId, status: 'completed' }),
    DonationRequest.countDocuments({ organization: orgId, status: 'pending' }),
    DonationRequest.countDocuments({ organization: orgId, status: { $in: ['approved', 'out_for_delivery'] } }),
  ]);

  // Monthly received
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  const monthlyReceived = await DonationRequest.aggregate([
    { $match: { organization: orgId, status: 'completed', createdAt: { $gte: sixMonthsAgo } } },
    {
      $group: {
        _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
        count: { $sum: 1 },
        weightKg: { $sum: '$estimatedWeightKg' },
      },
    },
    { $sort: { '_id.year': 1, '_id.month': 1 } },
  ]);

  res.json({
    success: true,
    data: {
      overview: {
        totalRequests,
        completedDonations,
        pendingRequests,
        activeRequests,
        totalFoodReceivedKg: organization.totalFoodReceived,
        successRate: totalRequests > 0 ? ((completedDonations / totalRequests) * 100).toFixed(1) : 0,
      },
      monthlyReceived,
    },
  });
});

module.exports = { getRestaurantAnalytics, getOrganizationAnalytics };
