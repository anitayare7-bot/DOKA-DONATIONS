const asyncHandler = require('express-async-handler');
const FoodListing = require('../models/FoodListing');
const Restaurant = require('../models/Restaurant');
const { deleteImage } = require('../config/cloudinary');

// @desc    Get all available food listings (public/org)
// @route   GET /api/food-listings
// @access  Private (org, admin)
const getFoodListings = asyncHandler(async (req, res) => {
  const {
    category, city, status, urgent, search,
    page = 1, limit = 12, sortBy = 'createdAt', order = 'desc'
  } = req.query;

  const query = {};

  // Default to available for organizations
  if (req.user.role === 'organization') {
    query.status = 'available';
    // Auto-expire listings past expiry
    query.expiryTime = { $gt: new Date() };
  } else if (status) {
    query.status = status;
  }

  if (category) query.category = category;
  if (city) query['pickupLocation.city'] = new RegExp(city, 'i');
  if (urgent === 'true') query.isUrgent = true;
  if (search) {
    query.$or = [
      { title: new RegExp(search, 'i') },
      { description: new RegExp(search, 'i') },
      { tags: new RegExp(search, 'i') },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const sortOrder = order === 'asc' ? 1 : -1;

  const [listings, total] = await Promise.all([
    FoodListing.find(query)
      .populate('restaurant', 'restaurantName address logo')
      .sort({ [sortBy]: sortOrder })
      .skip(skip)
      .limit(Number(limit)),
    FoodListing.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: listings,
    pagination: {
      total,
      page: Number(page),
      limit: Number(limit),
      pages: Math.ceil(total / Number(limit)),
    },
  });
});

// @desc    Get restaurant's own food listings
// @route   GET /api/food-listings/mine
// @access  Private (restaurant)
const getMyFoodListings = asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findOne({ user: req.user._id });
  if (!restaurant) {
    res.status(404);
    throw new Error('Restaurant profile not found');
  }

  const { status, page = 1, limit = 10 } = req.query;
  const query = { restaurant: restaurant._id };
  if (status) query.status = status;

  const skip = (Number(page) - 1) * Number(limit);

  const [listings, total] = await Promise.all([
    FoodListing.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    FoodListing.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: listings,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) },
  });
});

// @desc    Get single food listing
// @route   GET /api/food-listings/:id
// @access  Private
const getFoodListing = asyncHandler(async (req, res) => {
  const listing = await FoodListing.findById(req.params.id)
    .populate('restaurant', 'restaurantName address logo contactPhone')
    .populate('postedBy', 'name email');

  if (!listing) {
    res.status(404);
    throw new Error('Food listing not found');
  }

  // Increment views
  listing.views += 1;
  await listing.save({ validateBeforeSave: false });

  res.json({ success: true, data: listing });
});

// @desc    Create food listing
// @route   POST /api/food-listings
// @access  Private (restaurant)
const createFoodListing = asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findOne({ user: req.user._id });
  if (!restaurant) {
    res.status(404);
    throw new Error('Restaurant profile not found');
  }

  if (!req.user.isApproved) {
    res.status(403);
    throw new Error('Your account must be approved before posting listings');
  }

  const listingData = {
    ...req.body,
    restaurant: restaurant._id,
    postedBy: req.user._id,
    pickupLocation: req.body.pickupLocation || restaurant.address,
  };

  // Handle uploaded images
  if (req.files && req.files.length > 0) {
    listingData.images = req.files.map((file) => ({
      url: file.path,
      publicId: file.filename,
    }));
  }

  const listing = await FoodListing.create(listingData);

  res.status(201).json({ success: true, data: listing, message: 'Food listing created successfully' });
});

// @desc    Update food listing
// @route   PUT /api/food-listings/:id
// @access  Private (restaurant - own listing)
const updateFoodListing = asyncHandler(async (req, res) => {
  const listing = await FoodListing.findById(req.params.id);

  if (!listing) {
    res.status(404);
    throw new Error('Food listing not found');
  }

  // Check ownership
  if (listing.postedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to update this listing');
  }

  // Handle new images
  if (req.files && req.files.length > 0) {
    const newImages = req.files.map((file) => ({
      url: file.path,
      publicId: file.filename,
    }));
    req.body.images = [...(listing.images || []), ...newImages];
  }

  const updated = await FoodListing.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.json({ success: true, data: updated, message: 'Food listing updated' });
});

// @desc    Delete food listing
// @route   DELETE /api/food-listings/:id
// @access  Private (restaurant - own listing, admin)
const deleteFoodListing = asyncHandler(async (req, res) => {
  const listing = await FoodListing.findById(req.params.id);

  if (!listing) {
    res.status(404);
    throw new Error('Food listing not found');
  }

  if (listing.postedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to delete this listing');
  }

  // Delete images from Cloudinary
  for (const image of listing.images) {
    if (image.publicId) await deleteImage(image.publicId);
  }

  await listing.deleteOne();

  res.json({ success: true, message: 'Food listing deleted' });
});

// @desc    Remove specific image from listing
// @route   DELETE /api/food-listings/:id/images/:publicId
// @access  Private (restaurant)
const removeFoodImage = asyncHandler(async (req, res) => {
  const listing = await FoodListing.findById(req.params.id);

  if (!listing) {
    res.status(404);
    throw new Error('Listing not found');
  }

  if (listing.postedBy.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized');
  }

  const publicId = decodeURIComponent(req.params.publicId);
  await deleteImage(publicId);

  listing.images = listing.images.filter((img) => img.publicId !== publicId);
  await listing.save();

  res.json({ success: true, message: 'Image removed', data: listing });
});

module.exports = {
  getFoodListings,
  getMyFoodListings,
  getFoodListing,
  createFoodListing,
  updateFoodListing,
  deleteFoodListing,
  removeFoodImage,
};
