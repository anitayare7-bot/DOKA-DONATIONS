const asyncHandler = require('express-async-handler');
const DonationRequest = require('../models/DonationRequest');
const FoodListing = require('../models/FoodListing');
const Restaurant = require('../models/Restaurant');
const Organization = require('../models/Organization');
const User = require('../models/User');
const notificationService = require('../services/notificationService');

// @desc    Create donation request
// @route   POST /api/donation-requests
// @access  Private (organization)
const createDonationRequest = asyncHandler(async (req, res) => {
  const { foodListingId, requestNote, deliveryAddress } = req.body;

  const foodListing = await FoodListing.findById(foodListingId).populate('restaurant');
  if (!foodListing) {
    res.status(404);
    throw new Error('Food listing not found');
  }

  if (foodListing.status !== 'available') {
    res.status(400);
    throw new Error('This food listing is no longer available');
  }

  if (new Date(foodListing.expiryTime) < new Date()) {
    res.status(400);
    throw new Error('This food listing has expired');
  }

  const organization = await Organization.findOne({ user: req.user._id });
  if (!organization) {
    res.status(404);
    throw new Error('Organization profile not found');
  }

  // Check if already requested
  const existing = await DonationRequest.findOne({
    foodListing: foodListingId,
    organization: organization._id,
    status: { $in: ['pending', 'approved', 'out_for_delivery'] },
  });
  if (existing) {
    res.status(400);
    throw new Error('You have already requested this food listing');
  }

  const donationRequest = await DonationRequest.create({
    foodListing: foodListingId,
    restaurant: foodListing.restaurant._id,
    organization: organization._id,
    requestedBy: req.user._id,
    requestNote,
    deliveryAddress: deliveryAddress || organization.address,
    quantityReceived: foodListing.quantity.amount,
    quantityUnit: foodListing.quantity.unit,
    estimatedWeightKg: foodListing.estimatedWeight,
    statusHistory: [{ status: 'pending', updatedBy: req.user._id, note: 'Request submitted' }],
  });

  // Update listing status to pending
  foodListing.status = 'pending';
  await foodListing.save();

  // Notify restaurant
  const restaurantUser = await User.findById(foodListing.postedBy);
  if (restaurantUser) {
    await notificationService.notifyDonationRequest(restaurantUser._id, donationRequest, foodListing.title);
  }

  const populated = await donationRequest.populate([
    { path: 'foodListing', select: 'title images quantity category' },
    { path: 'restaurant', select: 'restaurantName address' },
    { path: 'organization', select: 'organizationName' },
  ]);

  res.status(201).json({ success: true, data: populated, message: 'Donation request submitted!' });
});

// @desc    Get donation requests for restaurant
// @route   GET /api/donation-requests/restaurant
// @access  Private (restaurant)
const getRestaurantDonationRequests = asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findOne({ user: req.user._id });
  if (!restaurant) {
    res.status(404);
    throw new Error('Restaurant not found');
  }

  const { status, page = 1, limit = 10 } = req.query;
  const query = { restaurant: restaurant._id };
  if (status) query.status = status;

  const skip = (Number(page) - 1) * Number(limit);

  const [requests, total] = await Promise.all([
    DonationRequest.find(query)
      .populate('foodListing', 'title images quantity category expiryTime')
      .populate('organization', 'organizationName type address logo')
      .populate('requestedBy', 'name email phone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    DonationRequest.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: requests,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) },
  });
});

// @desc    Get donation requests for organization
// @route   GET /api/donation-requests/organization
// @access  Private (organization)
const getOrganizationDonationRequests = asyncHandler(async (req, res) => {
  const organization = await Organization.findOne({ user: req.user._id });
  if (!organization) {
    res.status(404);
    throw new Error('Organization not found');
  }

  const { status, page = 1, limit = 10 } = req.query;
  const query = { organization: organization._id };
  if (status) query.status = status;

  const skip = (Number(page) - 1) * Number(limit);

  const [requests, total] = await Promise.all([
    DonationRequest.find(query)
      .populate('foodListing', 'title images quantity category expiryTime')
      .populate('restaurant', 'restaurantName address logo contactPhone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    DonationRequest.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: requests,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) },
  });
});

// @desc    Update donation request status (restaurant)
// @route   PUT /api/donation-requests/:id/status
// @access  Private (restaurant)
const updateDonationStatus = asyncHandler(async (req, res) => {
  const { status, note, deliveryPersonName, deliveryPersonPhone, estimatedDeliveryTime } = req.body;
  const request = await DonationRequest.findById(req.params.id)
    .populate('foodListing')
    .populate('organization');

  if (!request) {
    res.status(404);
    throw new Error('Donation request not found');
  }

  // Verify restaurant owns this request
  const restaurant = await Restaurant.findOne({ user: req.user._id });
  if (!restaurant || request.restaurant.toString() !== restaurant._id.toString()) {
    res.status(403);
    throw new Error('Not authorized');
  }

  const validTransitions = {
    pending: ['approved', 'rejected'],
    approved: ['out_for_delivery'],
    out_for_delivery: ['delivered'],
  };

  if (!validTransitions[request.status]?.includes(status)) {
    res.status(400);
    throw new Error(`Cannot transition from ${request.status} to ${status}`);
  }

  request.status = status;
  request.statusHistory.push({ status, updatedBy: req.user._id, note });

  if (status === 'rejected') {
    request.rejectionReason = note;
    request.foodListing.status = 'available';
    await request.foodListing.save();
  }
  if (status === 'approved') {
    request.restaurantNote = note;
    request.estimatedDeliveryTime = estimatedDeliveryTime;
    request.foodListing.status = 'reserved';
    await request.foodListing.save();
  }
  if (status === 'out_for_delivery') {
    request.deliveryPersonName = deliveryPersonName;
    request.deliveryPersonPhone = deliveryPersonPhone;
    request.trackingNote = note;
  }
  if (status === 'delivered') {
    request.actualDeliveryTime = new Date();
  }

  await request.save();

  // Send notifications
  const orgUser = await User.findById(request.requestedBy);
  if (orgUser) {
    if (status === 'approved') await notificationService.notifyRequestApproved(orgUser._id, request, request.foodListing.title);
    if (status === 'rejected') await notificationService.notifyRequestRejected(orgUser._id, request, request.foodListing.title, note);
    if (status === 'out_for_delivery') await notificationService.notifyOutForDelivery(orgUser._id, request, request.foodListing.title);
    if (status === 'delivered') await notificationService.notifyDelivered(orgUser._id, request, request.foodListing.title);
  }

  res.json({ success: true, data: request, message: `Status updated to ${status}` });
});

// @desc    Confirm receipt (organization)
// @route   PUT /api/donation-requests/:id/confirm-receipt
// @access  Private (organization)
const confirmReceipt = asyncHandler(async (req, res) => {
  const { receiptNote, rating, review } = req.body;
  const request = await DonationRequest.findById(req.params.id)
    .populate('foodListing')
    .populate('restaurant');

  if (!request) {
    res.status(404);
    throw new Error('Donation request not found');
  }

  const organization = await Organization.findOne({ user: req.user._id });
  if (!organization || request.organization.toString() !== organization._id.toString()) {
    res.status(403);
    throw new Error('Not authorized');
  }

  if (request.status !== 'delivered') {
    res.status(400);
    throw new Error('Can only confirm receipt after delivery');
  }

  request.status = 'completed';
  request.receiptConfirmed = true;
  request.receiptConfirmedAt = new Date();
  request.receiptNote = receiptNote;
  request.organizationRating = rating;
  request.organizationReview = review;
  request.statusHistory.push({ status: 'completed', updatedBy: req.user._id, note: receiptNote });

  // Mark food listing as completed
  await FoodListing.findByIdAndUpdate(request.foodListing._id, { status: 'completed' });

  // Update analytics
  await Restaurant.findByIdAndUpdate(request.restaurant._id, {
    $inc: {
      completedDonations: 1,
      totalFoodSaved: request.estimatedWeightKg || 0,
    },
  });
  await Organization.findByIdAndUpdate(organization._id, {
    $inc: {
      completedDonations: 1,
      totalFoodReceived: request.estimatedWeightKg || 0,
    },
  });

  await request.save();

  // Notify restaurant — find the user who owns this restaurant profile
  const restaurantDoc = await Restaurant.findById(request.restaurant._id);
  if (restaurantDoc) {
    await notificationService.notifyReceiptConfirmed(restaurantDoc.user, request, request.foodListing.title);
  }

  res.json({ success: true, data: request, message: 'Receipt confirmed. Donation completed!' });
});

// @desc    Get single donation request
// @route   GET /api/donation-requests/:id
// @access  Private
const getDonationRequest = asyncHandler(async (req, res) => {
  const request = await DonationRequest.findById(req.params.id)
    .populate('foodListing')
    .populate('restaurant', 'restaurantName address logo contactPhone')
    .populate('organization', 'organizationName type address logo')
    .populate('requestedBy', 'name email phone')
    .populate('statusHistory.updatedBy', 'name');

  if (!request) {
    res.status(404);
    throw new Error('Donation request not found');
  }

  res.json({ success: true, data: request });
});

module.exports = {
  createDonationRequest,
  getRestaurantDonationRequests,
  getOrganizationDonationRequests,
  updateDonationStatus,
  confirmReceipt,
  getDonationRequest,
};
