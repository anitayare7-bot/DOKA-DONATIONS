const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const Restaurant = require('../models/Restaurant');
const Organization = require('../models/Organization');
const FoodListing = require('../models/FoodListing');
const DonationRequest = require('../models/DonationRequest');
const Report = require('../models/Report');
const Notification = require('../models/Notification');
const notificationService = require('../services/notificationService');

// @desc    Get dashboard stats
// @route   GET /api/admin/stats
// @access  Private (admin)
const getStats = asyncHandler(async (req, res) => {
  const [
    totalUsers, totalRestaurants, totalOrganizations,
    pendingRestaurants, totalListings, activeListings,
    totalRequests, completedDonations, openReports,
  ] = await Promise.all([
    User.countDocuments({ role: { $ne: 'admin' } }),
    User.countDocuments({ role: 'restaurant' }),
    User.countDocuments({ role: 'organization' }),
    Restaurant.countDocuments({ approvalStatus: 'pending' }),
    FoodListing.countDocuments(),
    FoodListing.countDocuments({ status: 'available' }),
    DonationRequest.countDocuments(),
    DonationRequest.countDocuments({ status: 'completed' }),
    Report.countDocuments({ status: 'open' }),
  ]);

  // Total food saved (kg)
  const foodSaved = await Restaurant.aggregate([
    { $group: { _id: null, total: { $sum: '$totalFoodSaved' } } },
  ]);

  // Monthly donation trends (last 6 months)
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  const monthlyTrends = await DonationRequest.aggregate([
    { $match: { status: 'completed', createdAt: { $gte: sixMonthsAgo } } },
    {
      $group: {
        _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
        count: { $sum: 1 },
      },
    },
    { $sort: { '_id.year': 1, '_id.month': 1 } },
  ]);

  res.json({
    success: true,
    data: {
      totalUsers,
      totalRestaurants,
      totalOrganizations,
      pendingRestaurants,
      totalListings,
      activeListings,
      totalRequests,
      completedDonations,
      openReports,
      totalFoodSavedKg: foodSaved[0]?.total || 0,
      monthlyTrends,
    },
  });
});

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (admin)
const getAllUsers = asyncHandler(async (req, res) => {
  const { role, isActive, search, page = 1, limit = 20 } = req.query;
  const query = {};
  if (role) query.role = role;
  if (isActive !== undefined) query.isActive = isActive === 'true';
  if (search) {
    query.$or = [
      { name: new RegExp(search, 'i') },
      { email: new RegExp(search, 'i') },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [users, total] = await Promise.all([
    User.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    User.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: users,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) },
  });
});

// @desc    Get pending restaurants
// @route   GET /api/admin/restaurants/pending
// @access  Private (admin)
const getPendingRestaurants = asyncHandler(async (req, res) => {
  const restaurants = await Restaurant.find({ approvalStatus: 'pending' })
    .populate('user', 'name email phone createdAt')
    .sort({ createdAt: -1 });

  res.json({ success: true, data: restaurants });
});

// @desc    Approve/reject restaurant
// @route   PUT /api/admin/restaurants/:id/approval
// @access  Private (admin)
const updateRestaurantApproval = asyncHandler(async (req, res) => {
  const { status, note } = req.body; // status: 'approved' | 'rejected' | 'suspended'

  const restaurant = await Restaurant.findById(req.params.id).populate('user');
  if (!restaurant) {
    res.status(404);
    throw new Error('Restaurant not found');
  }

  restaurant.approvalStatus = status;
  restaurant.approvalNote = note;
  await restaurant.save();

  // Update user approval
  await User.findByIdAndUpdate(restaurant.user._id, {
    isApproved: status === 'approved',
    isActive: status !== 'suspended',
  });

  // Send notification
  if (status === 'approved') {
    await notificationService.notifyAccountApproved(restaurant.user._id, restaurant.restaurantName);
  } else if (status === 'rejected') {
    await notificationService.notifyAccountRejected(restaurant.user._id, restaurant.restaurantName, note);
  }

  res.json({ success: true, message: `Restaurant ${status}`, data: restaurant });
});

// @desc    Toggle user active status
// @route   PUT /api/admin/users/:id/toggle-status
// @access  Private (admin)
const toggleUserStatus = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  user.isActive = !user.isActive;
  await user.save({ validateBeforeSave: false });

  res.json({
    success: true,
    message: `User ${user.isActive ? 'activated' : 'suspended'}`,
    data: { isActive: user.isActive },
  });
});

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private (admin)
const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  if (user.role === 'admin') {
    res.status(400);
    throw new Error('Cannot delete admin users');
  }

  await user.deleteOne();
  res.json({ success: true, message: 'User deleted successfully' });
});

// @desc    Send platform announcement
// @route   POST /api/admin/announce
// @access  Private (admin)
const sendAnnouncement = asyncHandler(async (req, res) => {
  const { title, message, targetRole } = req.body;

  const query = targetRole ? { role: targetRole } : { role: { $ne: 'admin' } };
  const users = await User.find(query).select('_id');

  const notifications = users.map((u) => ({
    recipient: u._id,
    type: 'system_announcement',
    title,
    message,
    link: '/announcements',
  }));

  await Notification.insertMany(notifications);

  res.json({ success: true, message: `Announcement sent to ${users.length} users` });
});

// @desc    Get all reports
// @route   GET /api/admin/reports
// @access  Private (admin)
const getReports = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 10 } = req.query;
  const query = {};
  if (status) query.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [reports, total] = await Promise.all([
    Report.find(query)
      .populate('reportedBy', 'name email role')
      .populate('reportedUser', 'name email role')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Report.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: reports,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) },
  });
});

// @desc    Update report status
// @route   PUT /api/admin/reports/:id
// @access  Private (admin)
const updateReport = asyncHandler(async (req, res) => {
  const { status, adminNote } = req.body;
  const report = await Report.findByIdAndUpdate(
    req.params.id,
    { status, adminNote, resolvedBy: req.user._id, resolvedAt: status === 'resolved' ? new Date() : undefined },
    { new: true }
  );

  if (!report) {
    res.status(404);
    throw new Error('Report not found');
  }

  res.json({ success: true, data: report, message: 'Report updated' });
});

// @desc    Get all donations (admin view)
// @route   GET /api/admin/donations
// @access  Private (admin)
const getAllDonations = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const query = {};
  if (status) query.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [donations, total] = await Promise.all([
    DonationRequest.find(query)
      .populate('foodListing', 'title category')
      .populate('restaurant', 'restaurantName')
      .populate('organization', 'organizationName type')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    DonationRequest.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: donations,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) },
  });
});

module.exports = {
  getStats,
  getAllUsers,
  getPendingRestaurants,
  updateRestaurantApproval,
  toggleUserStatus,
  deleteUser,
  sendAnnouncement,
  getReports,
  updateReport,
  getAllDonations,
};
