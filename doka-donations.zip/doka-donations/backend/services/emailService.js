const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendEmail = async ({ to, subject, html, text }) => {
  try {
    const info = await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'DOKA Donations <noreply@dokadonations.com>',
      to,
      subject,
      html,
      text,
    });
    console.log('Email sent:', info.messageId);
    return info;
  } catch (error) {
    console.error('Email send error:', error.message);
    throw new Error('Email could not be sent');
  }
};

const sendPasswordResetEmail = async (email, resetUrl) => {
  const html = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8" /><style>
      body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px; }
      .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; }
      .header { background: linear-gradient(135deg, #16a34a, #15803d); padding: 30px; text-align: center; }
      .header h1 { color: white; margin: 0; font-size: 24px; }
      .body { padding: 30px; }
      .btn { display: inline-block; background: #16a34a; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 20px 0; }
      .footer { background: #f9f9f9; padding: 20px; text-align: center; color: #666; font-size: 12px; }
    </style></head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🌿 DOKA Donations</h1>
        </div>
        <div class="body">
          <h2>Password Reset Request</h2>
          <p>You requested to reset your password. Click the button below to proceed:</p>
          <a href="${resetUrl}" class="btn">Reset Password</a>
          <p>This link expires in <strong>10 minutes</strong>.</p>
          <p>If you did not request this, please ignore this email. Your account is safe.</p>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} DOKA Donations. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  await sendEmail({
    to: email,
    subject: 'Password Reset - DOKA Donations',
    html,
    text: `Reset your password: ${resetUrl}`,
  });
};

module.exports = { sendEmail, sendPasswordResetEmail };
