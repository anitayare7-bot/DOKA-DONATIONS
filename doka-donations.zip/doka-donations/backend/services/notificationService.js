const Notification = require('../models/Notification');

/**
 * Create a notification for a user
 */
const createNotification = async ({ recipient, type, title, message, link, relatedId, relatedModel }) => {
  try {
    const notification = await Notification.create({
      recipient,
      type,
      title,
      message,
      link,
      relatedId,
      relatedModel,
    });
    return notification;
  } catch (error) {
    console.error('Error creating notification:', error.message);
    return null;
  }
};

/**
 * Notification templates for common events
 */
const notifyDonationRequest = async (restaurantUserId, donationRequest, foodTitle) => {
  await createNotification({
    recipient: restaurantUserId,
    type: 'donation_request',
    title: 'New Donation Request',
    message: `An organization has requested your food listing: "${foodTitle}"`,
    link: `/restaurant/donations/${donationRequest._id}`,
    relatedId: donationRequest._id,
    relatedModel: 'DonationRequest',
  });
};

const notifyRequestApproved = async (orgUserId, donationRequest, foodTitle) => {
  await createNotification({
    recipient: orgUserId,
    type: 'request_approved',
    title: 'Donation Request Approved!',
    message: `Your request for "${foodTitle}" has been approved. Delivery is being arranged.`,
    link: `/organization/donations/${donationRequest._id}`,
    relatedId: donationRequest._id,
    relatedModel: 'DonationRequest',
  });
};

const notifyRequestRejected = async (orgUserId, donationRequest, foodTitle, reason) => {
  await createNotification({
    recipient: orgUserId,
    type: 'request_rejected',
    title: 'Donation Request Rejected',
    message: `Your request for "${foodTitle}" was rejected. ${reason ? `Reason: ${reason}` : ''}`,
    link: `/organization/donations/${donationRequest._id}`,
    relatedId: donationRequest._id,
    relatedModel: 'DonationRequest',
  });
};

const notifyOutForDelivery = async (orgUserId, donationRequest, foodTitle) => {
  await createNotification({
    recipient: orgUserId,
    type: 'out_for_delivery',
    title: 'Food is On the Way!',
    message: `"${foodTitle}" is out for delivery to your organization.`,
    link: `/organization/donations/${donationRequest._id}`,
    relatedId: donationRequest._id,
    relatedModel: 'DonationRequest',
  });
};

const notifyDelivered = async (orgUserId, donationRequest, foodTitle) => {
  await createNotification({
    recipient: orgUserId,
    type: 'delivered',
    title: 'Food Delivered',
    message: `"${foodTitle}" has been delivered. Please confirm receipt.`,
    link: `/organization/donations/${donationRequest._id}`,
    relatedId: donationRequest._id,
    relatedModel: 'DonationRequest',
  });
};

const notifyReceiptConfirmed = async (restaurantUserId, donationRequest, foodTitle) => {
  await createNotification({
    recipient: restaurantUserId,
    type: 'receipt_confirmed',
    title: 'Donation Receipt Confirmed',
    message: `The organization has confirmed receipt of "${foodTitle}". Donation completed!`,
    link: `/restaurant/donations/${donationRequest._id}`,
    relatedId: donationRequest._id,
    relatedModel: 'DonationRequest',
  });
};

const notifyAccountApproved = async (userId, restaurantName) => {
  await createNotification({
    recipient: userId,
    type: 'account_approved',
    title: 'Account Approved!',
    message: `Congratulations! Your restaurant "${restaurantName}" has been approved. You can now post food listings.`,
    link: '/restaurant/dashboard',
  });
};

const notifyAccountRejected = async (userId, restaurantName, reason) => {
  await createNotification({
    recipient: userId,
    type: 'account_rejected',
    title: 'Account Application Rejected',
    message: `Your application for "${restaurantName}" was rejected. ${reason ? `Reason: ${reason}` : 'Please contact support.'}`,
    link: '/restaurant/profile',
  });
};

module.exports = {
  createNotification,
  notifyDonationRequest,
  notifyRequestApproved,
  notifyRequestRejected,
  notifyOutForDelivery,
  notifyDelivered,
  notifyReceiptConfirmed,
  notifyAccountApproved,
  notifyAccountRejected,
};
