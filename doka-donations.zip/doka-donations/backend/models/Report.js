const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
  reportedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  reportedUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  relatedDonation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DonationRequest',
  },
  relatedListing: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'FoodListing',
  },
  type: {
    type: String,
    enum: ['food_quality', 'no_show', 'fraud', 'inappropriate_content', 'spam', 'other'],
    required: true,
  },
  subject: { type: String, required: true },
  description: { type: String, required: true, maxlength: 1000 },
  evidence: [{
    url: String,
    publicId: String,
  }],
  status: {
    type: String,
    enum: ['open', 'under_review', 'resolved', 'dismissed'],
    default: 'open',
  },
  adminNote: String,
  resolvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  resolvedAt: Date,
}, {
  timestamps: true,
});

module.exports = mongoose.model('Report', reportSchema);
