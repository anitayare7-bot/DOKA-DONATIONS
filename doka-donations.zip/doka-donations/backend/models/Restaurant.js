const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true,
  },
  restaurantName: {
    type: String,
    required: [true, 'Restaurant name is required'],
    trim: true,
  },
  description: { type: String, maxlength: 500 },
  cuisine: [String],
  logo: {
    url: { type: String, default: '' },
    publicId: { type: String, default: '' },
  },
  coverImage: {
    url: { type: String, default: '' },
    publicId: { type: String, default: '' },
  },
  address: {
    street: { type: String, required: true },
    city: { type: String, required: true },
    state: String,
    country: { type: String, default: 'Nigeria' },
    zipCode: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  operatingHours: {
    monday: { open: String, close: String, isClosed: Boolean },
    tuesday: { open: String, close: String, isClosed: Boolean },
    wednesday: { open: String, close: String, isClosed: Boolean },
    thursday: { open: String, close: String, isClosed: Boolean },
    friday: { open: String, close: String, isClosed: Boolean },
    saturday: { open: String, close: String, isClosed: Boolean },
    sunday: { open: String, close: String, isClosed: Boolean },
  },
  contactPhone: String,
  website: String,
  // Analytics
  totalDonations: { type: Number, default: 0 },
  totalFoodSaved: { type: Number, default: 0 }, // in kg
  completedDonations: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  reviewCount: { type: Number, default: 0 },
  // Status
  isVerified: { type: Boolean, default: false },
  approvalStatus: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'suspended'],
    default: 'pending',
  },
  approvalNote: String,
}, {
  timestamps: true,
});

module.exports = mongoose.model('Restaurant', restaurantSchema);
