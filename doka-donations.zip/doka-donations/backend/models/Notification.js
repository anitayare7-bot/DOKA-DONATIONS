const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  recipient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  type: {
    type: String,
    enum: [
      'donation_request',
      'request_approved',
      'request_rejected',
      'out_for_delivery',
      'delivered',
      'receipt_confirmed',
      'new_food_listing',
      'listing_expiring',
      'account_approved',
      'account_rejected',
      'account_suspended',
      'system_announcement',
      'review_received',
    ],
    required: true,
  },
  title: { type: String, required: true },
  message: { type: String, required: true },
  link: String, // Frontend URL to navigate to
  relatedId: mongoose.Schema.Types.ObjectId, // Related document ID
  relatedModel: String, // 'FoodListing', 'DonationRequest', etc.
  isRead: { type: Boolean, default: false },
  readAt: Date,
}, {
  timestamps: true,
});

notificationSchema.index({ recipient: 1, isRead: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);
