const mongoose = require('mongoose');

const donationRequestSchema = new mongoose.Schema({
  foodListing: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'FoodListing',
    required: true,
  },
  restaurant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true,
  },
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true,
  },
  requestedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  // Delivery details
  deliveryAddress: {
    street: String,
    city: String,
    state: String,
    country: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  // Status workflow: pending -> approved/rejected -> out_for_delivery -> delivered -> completed
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'out_for_delivery', 'delivered', 'completed', 'cancelled'],
    default: 'pending',
  },
  statusHistory: [{
    status: String,
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    note: String,
    timestamp: { type: Date, default: Date.now },
  }],
  // Notes
  requestNote: String,
  restaurantNote: String,
  rejectionReason: String,
  // Delivery info
  estimatedDeliveryTime: Date,
  actualDeliveryTime: Date,
  deliveryPersonName: String,
  deliveryPersonPhone: String,
  trackingNote: String,
  // Receipt confirmation
  receiptConfirmed: { type: Boolean, default: false },
  receiptConfirmedAt: Date,
  receiptNote: String,
  // Ratings
  organizationRating: { type: Number, min: 1, max: 5 },
  organizationReview: String,
  restaurantRating: { type: Number, min: 1, max: 5 },
  restaurantReview: String,
  // Quantity details
  quantityReceived: Number,
  quantityUnit: String,
  estimatedWeightKg: Number,
}, {
  timestamps: true,
});

// Index for efficient queries
donationRequestSchema.index({ status: 1, restaurant: 1 });
donationRequestSchema.index({ status: 1, organization: 1 });
donationRequestSchema.index({ foodListing: 1 });

module.exports = mongoose.model('DonationRequest', donationRequestSchema);
