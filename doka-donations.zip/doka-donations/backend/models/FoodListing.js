const mongoose = require('mongoose');

const foodListingSchema = new mongoose.Schema({
  restaurant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true,
  },
  postedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  title: {
    type: String,
    required: [true, 'Food listing title is required'],
    trim: true,
    maxlength: 100,
  },
  description: {
    type: String,
    maxlength: 500,
  },
  category: {
    type: String,
    enum: ['cooked_meals', 'raw_produce', 'baked_goods', 'beverages', 'packaged_food', 'dairy', 'meat_poultry', 'seafood', 'grains_cereals', 'fruits_vegetables', 'other'],
    required: true,
  },
  images: [{
    url: String,
    publicId: String,
  }],
  quantity: {
    amount: { type: Number, required: true, min: 0.1 },
    unit: {
      type: String,
      enum: ['kg', 'lbs', 'liters', 'portions', 'boxes', 'bags', 'trays', 'pieces'],
      required: true,
    },
  },
  estimatedWeight: Number, // in kg, for analytics
  expiryTime: {
    type: Date,
    required: [true, 'Expiry time is required'],
  },
  pickupLocation: {
    address: String,
    city: String,
    state: String,
    country: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  dietaryInfo: {
    isVegetarian: { type: Boolean, default: false },
    isVegan: { type: Boolean, default: false },
    isHalal: { type: Boolean, default: false },
    isKosher: { type: Boolean, default: false },
    allergens: [String],
  },
  preparationDate: Date,
  status: {
    type: String,
    enum: ['available', 'pending', 'reserved', 'completed', 'expired', 'cancelled'],
    default: 'available',
  },
  isUrgent: { type: Boolean, default: false }, // expires soon
  views: { type: Number, default: 0 },
  tags: [String],
}, {
  timestamps: true,
});

// Auto-set urgent if expiry within 6 hours
foodListingSchema.pre('save', function (next) {
  const sixHoursFromNow = new Date(Date.now() + 6 * 60 * 60 * 1000);
  if (this.expiryTime <= sixHoursFromNow) {
    this.isUrgent = true;
  }
  next();
});

// Index for fast search
foodListingSchema.index({ status: 1, category: 1, expiryTime: 1 });
foodListingSchema.index({ 'pickupLocation.city': 1 });

module.exports = mongoose.model('FoodListing', foodListingSchema);
