const mongoose = require('mongoose');

const organizationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true,
  },
  organizationName: {
    type: String,
    required: [true, 'Organization name is required'],
    trim: true,
  },
  type: {
    type: String,
    enum: ['ngo', 'charity', 'food_bank', 'shelter', 'community_center', 'other'],
    required: true,
  },
  description: { type: String, maxlength: 500 },
  logo: {
    url: { type: String, default: '' },
    publicId: { type: String, default: '' },
  },
  registrationNumber: String,
  address: {
    street: { type: String, required: true },
    city: { type: String, required: true },
    state: String,
    country: { type: String, default: 'Nigeria' },
    zipCode: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  contactPhone: String,
  website: String,
  socialMedia: {
    facebook: String,
    twitter: String,
    instagram: String,
  },
  // Capacity & operations
  peopleServedPerDay: Number,
  operatingDays: [String],
  // Analytics
  totalReceived: { type: Number, default: 0 },
  totalFoodReceived: { type: Number, default: 0 }, // in kg
  completedDonations: { type: Number, default: 0 },
  isVerified: { type: Boolean, default: false },
}, {
  timestamps: true,
});

module.exports = mongoose.model('Organization', organizationSchema);
