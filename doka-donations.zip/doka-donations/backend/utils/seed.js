const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');

dotenv.config({ path: require('path').join(__dirname, '../.env') });

const User = require('../models/User');
const Restaurant = require('../models/Restaurant');
const Organization = require('../models/Organization');
const FoodListing = require('../models/FoodListing');
const DonationRequest = require('../models/DonationRequest');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/doka-donations';

const seed = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('Connected to MongoDB for seeding...');

    // Clean existing data
    await Promise.all([
      User.deleteMany(),
      Restaurant.deleteMany(),
      Organization.deleteMany(),
      FoodListing.deleteMany(),
      DonationRequest.deleteMany(),
    ]);
    console.log('Cleared existing data');

    // Create Admin
    const adminUser = await User.create({
      name: 'DOKA Admin',
      email: 'admin@dokadonations.com',
      password: 'Admin@123',
      role: 'admin',
      isApproved: true,
      isActive: true,
    });
    console.log('Admin created: admin@dokadonations.com / Admin@123');

    // Create Restaurant Users
    const restUser1 = await User.create({
      name: 'Chef Emeka',
      email: 'restaurant1@dokadonations.com',
      password: 'Rest@123',
      role: 'restaurant',
      isApproved: true,
      phone: '+234 801 234 5678',
    });

    const restUser2 = await User.create({
      name: 'Amaka Osei',
      email: 'restaurant2@dokadonations.com',
      password: 'Rest@123',
      role: 'restaurant',
      isApproved: true,
      phone: '+234 802 345 6789',
    });

    const restUser3 = await User.create({
      name: 'Lagos Bistro',
      email: 'restaurant3@dokadonations.com',
      password: 'Rest@123',
      role: 'restaurant',
      isApproved: false, // Pending approval
      phone: '+234 803 456 7890',
    });

    // Create Restaurant Profiles
    const restaurant1 = await Restaurant.create({
      user: restUser1._id,
      restaurantName: "Emeka's Kitchen",
      description: 'Authentic Nigerian cuisine in the heart of Abuja',
      cuisine: ['Nigerian', 'African', 'Continental'],
      address: { street: '12 Wuse Zone 4', city: 'Abuja', state: 'FCT', country: 'Nigeria' },
      contactPhone: '+234 801 234 5678',
      approvalStatus: 'approved',
      isVerified: true,
      totalFoodSaved: 145.5,
      completedDonations: 23,
    });

    const restaurant2 = await Restaurant.create({
      user: restUser2._id,
      restaurantName: 'Amaka\'s Catering',
      description: 'Event catering and daily meals, serving Lagos since 2015',
      cuisine: ['Nigerian', 'Continental'],
      address: { street: '45 Victoria Island', city: 'Lagos', state: 'Lagos', country: 'Nigeria' },
      contactPhone: '+234 802 345 6789',
      approvalStatus: 'approved',
      totalFoodSaved: 89.2,
      completedDonations: 14,
    });

    const restaurant3 = await Restaurant.create({
      user: restUser3._id,
      restaurantName: 'Lagos Bistro',
      description: 'Fine dining restaurant on the island',
      cuisine: ['Continental', 'French'],
      address: { street: '2 Ozumba Mbadiwe', city: 'Lagos', state: 'Lagos', country: 'Nigeria' },
      approvalStatus: 'pending',
    });

    // Update user approvals
    await User.findByIdAndUpdate(restUser1._id, { isApproved: true });
    await User.findByIdAndUpdate(restUser2._id, { isApproved: true });

    // Create Organization Users
    const orgUser1 = await User.create({
      name: 'Hope Foundation',
      email: 'org1@dokadonations.com',
      password: 'Org@123',
      role: 'organization',
      isApproved: true,
      phone: '+234 804 567 8901',
    });

    const orgUser2 = await User.create({
      name: 'Feed Abuja NGO',
      email: 'org2@dokadonations.com',
      password: 'Org@123',
      role: 'organization',
      isApproved: true,
      phone: '+234 805 678 9012',
    });

    // Create Organization Profiles
    const org1 = await Organization.create({
      user: orgUser1._id,
      organizationName: 'Hope Foundation Nigeria',
      type: 'ngo',
      description: 'Feeding the hungry and reducing food waste across Nigeria',
      address: { street: '7 Gwarinpa Estate', city: 'Abuja', state: 'FCT', country: 'Nigeria' },
      contactPhone: '+234 804 567 8901',
      peopleServedPerDay: 200,
      completedDonations: 18,
      totalFoodReceived: 112.3,
    });

    const org2 = await Organization.create({
      user: orgUser2._id,
      organizationName: 'Feed Abuja Initiative',
      type: 'food_bank',
      description: 'Community food bank serving low-income families in Abuja',
      address: { street: '15 Kubwa District', city: 'Abuja', state: 'FCT', country: 'Nigeria' },
      contactPhone: '+234 805 678 9012',
      peopleServedPerDay: 350,
      completedDonations: 31,
      totalFoodReceived: 289.7,
    });

    // Create Food Listings
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
    const in6hours = new Date(Date.now() + 6 * 60 * 60 * 1000);
    const in2days = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000);

    const listing1 = await FoodListing.create({
      restaurant: restaurant1._id,
      postedBy: restUser1._id,
      title: 'Jollof Rice & Stew (Party Size)',
      description: 'Leftover from today\'s event. Fresh jollof rice with tomato stew. Serves approximately 50 people.',
      category: 'cooked_meals',
      images: [{ url: 'https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?w=800', publicId: 'seed_1' }],
      quantity: { amount: 25, unit: 'kg' },
      estimatedWeight: 25,
      expiryTime: tomorrow,
      pickupLocation: { address: '12 Wuse Zone 4', city: 'Abuja', state: 'FCT', country: 'Nigeria' },
      dietaryInfo: { isHalal: true },
      status: 'available',
      tags: ['jollof', 'rice', 'party leftovers'],
    });

    const listing2 = await FoodListing.create({
      restaurant: restaurant1._id,
      postedBy: restUser1._id,
      title: 'Assorted Bread Rolls',
      description: 'Freshly baked bread rolls from this morning. Still warm!',
      category: 'baked_goods',
      images: [{ url: 'https://images.unsplash.com/photo-1608198093002-ad4e005484ec?w=800', publicId: 'seed_2' }],
      quantity: { amount: 60, unit: 'pieces' },
      estimatedWeight: 6,
      expiryTime: in6hours,
      isUrgent: true,
      pickupLocation: { address: '12 Wuse Zone 4', city: 'Abuja', state: 'FCT', country: 'Nigeria' },
      status: 'available',
      tags: ['bread', 'baked', 'urgent'],
    });

    const listing3 = await FoodListing.create({
      restaurant: restaurant2._id,
      postedBy: restUser2._id,
      title: 'Vegetable Stir Fry & Rice',
      description: 'Catering surplus from a corporate event. Mixed vegetables with fried rice.',
      category: 'cooked_meals',
      images: [{ url: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800', publicId: 'seed_3' }],
      quantity: { amount: 15, unit: 'kg' },
      estimatedWeight: 15,
      expiryTime: tomorrow,
      pickupLocation: { address: '45 Victoria Island', city: 'Lagos', state: 'Lagos', country: 'Nigeria' },
      dietaryInfo: { isVegetarian: true, isVegan: true },
      status: 'available',
      tags: ['vegetarian', 'rice', 'vegetables'],
    });

    const listing4 = await FoodListing.create({
      restaurant: restaurant2._id,
      postedBy: restUser2._id,
      title: 'Fresh Fruit Platter',
      description: 'Assorted fresh cut fruits - mango, watermelon, pineapple, bananas.',
      category: 'fruits_vegetables',
      images: [{ url: 'https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?w=800', publicId: 'seed_4' }],
      quantity: { amount: 10, unit: 'kg' },
      estimatedWeight: 10,
      expiryTime: in2days,
      pickupLocation: { address: '45 Victoria Island', city: 'Lagos', state: 'Lagos', country: 'Nigeria' },
      dietaryInfo: { isVegetarian: true, isVegan: true, isHalal: true, isKosher: true },
      status: 'available',
    });

    // Create a sample completed donation request
    const completedRequest = await DonationRequest.create({
      foodListing: listing1._id,
      restaurant: restaurant1._id,
      organization: org1._id,
      requestedBy: orgUser1._id,
      status: 'completed',
      requestNote: 'We serve 200+ people daily and this would help greatly.',
      deliveryAddress: { street: '7 Gwarinpa Estate', city: 'Abuja', state: 'FCT', country: 'Nigeria' },
      estimatedWeightKg: 25,
      receiptConfirmed: true,
      receiptConfirmedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      statusHistory: [
        { status: 'pending', note: 'Request submitted' },
        { status: 'approved', note: 'Approved for delivery' },
        { status: 'out_for_delivery', note: 'Driver on the way' },
        { status: 'delivered', note: 'Food delivered successfully' },
        { status: 'completed', note: 'Receipt confirmed by organization' },
      ],
    });

    console.log('\n🌿 DOKA Donations Seed Data Created Successfully!\n');
    console.log('='.repeat(50));
    console.log('LOGIN CREDENTIALS:');
    console.log('='.repeat(50));
    console.log('ADMIN:');
    console.log('  Email: admin@dokadonations.com');
    console.log('  Password: Admin@123');
    console.log('\nRESTAURANT 1 (Approved):');
    console.log("  Email: restaurant1@dokadonations.com");
    console.log('  Password: Rest@123');
    console.log('\nRESTAURANT 2 (Approved):');
    console.log('  Email: restaurant2@dokadonations.com');
    console.log('  Password: Rest@123');
    console.log('\nRESTAURANT 3 (Pending Approval):');
    console.log('  Email: restaurant3@dokadonations.com');
    console.log('  Password: Rest@123');
    console.log('\nORGANIZATION 1 (Hope Foundation):');
    console.log('  Email: org1@dokadonations.com');
    console.log('  Password: Org@123');
    console.log('\nORGANIZATION 2 (Feed Abuja):');
    console.log('  Email: org2@dokadonations.com');
    console.log('  Password: Org@123');
    console.log('='.repeat(50));

    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
};

seed();
